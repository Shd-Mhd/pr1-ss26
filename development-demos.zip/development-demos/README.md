# Entwicklungsumgebung mit VS Code, Docker und Dev Containers

Diese Anleitung beschreibt die Schritte zur Installation von Visual Studio Code, Docker und der Dev-Container-Erweiterung.

---

## 1. Visual Studio Code installieren

**Download:** [https://code.visualstudio.com/](https://code.visualstudio.com/)

**Schritte:**
1. Webseite öffnen.
2. Betriebssystem auswählen.
3. Installationsdatei herunterladen.
4. Installation ausführen.
5. VS Code starten.

---

## 2. Docker installieren

**Download:** [https://www.docker.com/products/docker-desktop](https://www.docker.com/products/docker-desktop)

**Schritte:**
1. Webseite öffnen.
2. Betriebssystem auswählen.
3. Docker Desktop herunterladen.
4. Installation ausführen.
5. Docker starten.
6. Überprüfen in Terminal oder Kommandozeile mit:
   ```bash
   docker --version
   ```

---

## 3. Dev-Container-Erweiterung installieren

**Schritte:**
1. VS Code öffnen.
2. Erweiterungsansicht (_Extensions_) öffnen (`Strg+Shift+X`).
3. Nach **"Dev Containers"** suchen.
4. Erweiterung von Microsoft installieren.

---

## 4. Dev-Container starten

**Entwicklungsumgebung in Dev-Container öffnen:**
1. Repository aus Gitty lokal klonen, z. B. über Terminal oder Git-Client.
```bash
git clone https://gitty.informatik.hs-mannheim.de/PR1-W-SS26/development-demos.git
```
2. VS Code starten.
3. Den geklonten Projektordner über „Datei → Ordner öffnen…“ auswählen.
4. Befehlspalette öffnen (`Strg+Shift+P`).
5. Folgenden Befehl eingeben: 
```
Dev Containers: Open Folder in Container...
```
6. Die Container-Umgebung wird automatisch erkannt und gestartet.
7. Das Projekt öffnet sich im Container und ist einsatzbereit.
8. Zum Testen folgenden Befehl im Terminal eingeben:
	```
	javac --version
	```
	Ergebnis: `javac 21.0.8`
---

## Hinweise

- Docker muss aktiv sein, bevor VS Code mit Containern arbeitet.
- Bei Problemen: VS Code und Docker neu starten.
- Weitere Informationen:
  - [VS Code Dokumentation](https://code.visualstudio.com/docs)
  - [Docker Dokumentation](https://docs.docker.com/)
  - [Dev Containers](https://containers.dev/)
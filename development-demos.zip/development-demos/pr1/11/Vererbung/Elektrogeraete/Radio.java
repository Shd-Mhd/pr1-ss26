package Elektrogeraete;

public class Radio extends Elektrogeraet {
	private int lautstaerke;

	private void lautstaerkeAendern(int wert) {
		if (this.isOn) {
			int neueLautstaerke = lautstaerke + wert;
			if (neueLautstaerke < 0) {
				neueLautstaerke = 0;
			} else if (neueLautstaerke > 10) {
				neueLautstaerke = 10;
			}
			this.lautstaerke = neueLautstaerke;
			System.out.println("Die Laustärke wurde auf "+ this.lautstaerke + " geändert.");
		}else{
			System.out.println("Das Radio muss erst eingeschaltet werden.");
		}
	}

	public void lautstaerkeErhoehen() {
		lautstaerkeAendern(1);	
	}

	public void lautstaerkeVerringern() {
		lautstaerkeAendern(-1);
	}
}

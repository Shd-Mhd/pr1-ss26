package Elektrogeraete;

public class Wasserkocher extends Elektrogeraet{
	private short temperatur;

	public void setTemperatur(short temperatur) {
		if (temperatur <= 100) {
			this.temperatur = temperatur;
		} else {
			this.temperatur = 100;
		}
	}

	public void wasserKochen() {
		if (this.isOn) {
			System.out.println("Das Wasser wird auf " + this.temperatur + "° erhitzt.");
		}else{
			System.out.println("Der Wasserkocher muss erst eingeschaltet werden.");
		}
	}
}

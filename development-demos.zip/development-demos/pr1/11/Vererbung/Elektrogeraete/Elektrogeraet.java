package Elektrogeraete;

public class Elektrogeraet {
	protected boolean isOn;

	Elektrogeraet() {
		this.isOn = false;
	}

	public void anschalten() {
		this.isOn = true;
	}

	public void ausschalten() {
		this.isOn = false;
	}
}

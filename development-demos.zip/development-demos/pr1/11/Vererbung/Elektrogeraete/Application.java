package Elektrogeraete;

public class Application {
	public static void main(String[] args) {
		Elektrogeraet[] geraete = new Elektrogeraet[5];
		Radio r1 = new Radio();
		geraete[0] = r1;
		Radio r2 = new Radio();
		geraete[1] = r2;
		Radio r3 = new Radio();
		geraete[2] = r3;
		Radio r4 = new Radio();
		geraete[3] = r4;
		Wasserkocher w1 = new Wasserkocher();
		geraete[4] = w1;

		for (Elektrogeraet elektrogeraet : geraete) {
			elektrogeraet.anschalten();
		}

		r2.lautstaerkeErhoehen();
		r3.lautstaerkeErhoehen();
		r3.lautstaerkeErhoehen();
		w1.setTemperatur((short)70);
		w1.wasserKochen();

		for (Elektrogeraet elektrogeraet : geraete) {
			elektrogeraet.ausschalten();
		}
		w1.wasserKochen();
		r1.lautstaerkeErhoehen();
	}
}

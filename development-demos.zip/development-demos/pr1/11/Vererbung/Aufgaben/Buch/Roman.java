package Buch;

public class Roman extends Buch {
	private String genre;

	public Roman(String titel, String isbn, short seitenzahl, String genre) {
		super(titel, isbn, seitenzahl);
		this.genre = genre;
	}

	public String getGenre() {
		return genre;
	}

	@Override
	public String ausgabeString() {
		return "Roman [titel=" + titel + ", genre=" + genre + ", isbn=" + isbn + ", seitenzahl=" + seitenzahl + "]";
	}
}

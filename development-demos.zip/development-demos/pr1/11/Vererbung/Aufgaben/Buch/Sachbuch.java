package Buch;

public class Sachbuch extends Buch {
	private String fachgebiet;

	public Sachbuch(String titel, String isbn, short seitenzahl, String fachgebiet) {
		super(titel, isbn, seitenzahl);
		this.fachgebiet = fachgebiet;
	}

	public String getFachgebiet() {
		return fachgebiet;
	}

	@Override
	public String ausgabeString() {
		return "Sachbuch [titel=" + titel + ", fachgebiet=" + fachgebiet + ", isbn=" + isbn + ", seitenzahl="
				+ seitenzahl + "]";
	}

}

package Buch;

public final class LustigesTaschenbuch extends Buch{

    private int nummer;

    public LustigesTaschenbuch(String isbn, short seitenzahl, int nummer) {
		super("Lustiges Taschenbuch", isbn,seitenzahl);
        this.nummer = nummer;
    }

    public int getNummer() {
        return nummer;
    }

    public void lesen() {
        System.out.println("Du liest LTB Nr. " + nummer);
    }

	@Override
	public String ausgabeString() {
		return "Lustiges Taschenbuch [Nr=" + nummer + ", isbn=" + isbn + ", seitenzahl="
				+ seitenzahl + "]";
	}
}

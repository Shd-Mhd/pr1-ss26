package Buch;

public class Kinderbuch extends Buch {

	private short altersfreigabe;

	public Kinderbuch(String titel, String isbn, short seitenzahl, short altersfreigabe) {
		super(titel, isbn, seitenzahl);
		this.altersfreigabe = altersfreigabe;
	}

	public short getAltersfreigabe() {
		return altersfreigabe;
	}

	@Override
	public String ausgabeString() {
		return "Kinderbuch [titel=" + titel + ", altersfreigabe=" + altersfreigabe + ", isbn=" + isbn + ", seitenzahl="
				+ seitenzahl + "]";
	}

}

package Buch;

public class Buch {
	protected String titel;
	protected String isbn;
	protected short seitenzahl;
	
	public Buch(String titel, String isbn, short seitenzahl) {
		this.titel = titel;
		this.isbn = isbn;
		this.seitenzahl = seitenzahl;
	}

	public String getTitel() {
		return titel;
	}

	public String getIsbn() {
		return isbn;
	}

	public short getSeitenzahl() {
		return seitenzahl;
	}

	public String ausgabeString() {
		return "Buch [titel=" + titel + ", isbn=" + isbn + ", seitenzahl=" + seitenzahl + "]";
	}
	
}

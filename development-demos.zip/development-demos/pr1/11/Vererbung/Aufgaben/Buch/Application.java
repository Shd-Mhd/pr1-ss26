package Buch;

public class Application {
	public static void main(String[] args) {
		Buch[] buecherschrank = new Buch[4];
		Buch buch = new Buch("Lustiges Taschenbuch", "978‑3‑7704‑0001‑0", (short)320);
		buecherschrank[0] = buch;
		Roman roman = new Roman("Das Geschenk des Meeres", "978‑6‑3838‑0301‑0", (short)452, "Thriller");
		buecherschrank[1] = roman;
		Sachbuch sachbuch = new Sachbuch("Organisch", "978-1-4019-7136-6", (short)336, "Naturwissenschaften"); 
		buecherschrank[2] = sachbuch;
		Kinderbuch kinderbuch = new Kinderbuch("Animox Origins", "978-3-7512-0568-9", (short)208, (short)9);
		buecherschrank[3] = kinderbuch;

		short seitenzahlGesamt = 0;
		for (Buch buchInSchrank : buecherschrank) {
			System.out.println(buchInSchrank.ausgabeString());
			seitenzahlGesamt += buchInSchrank.seitenzahl;
		}
		System.out.println("Gelesene Seiten: " + seitenzahlGesamt);
	}
}

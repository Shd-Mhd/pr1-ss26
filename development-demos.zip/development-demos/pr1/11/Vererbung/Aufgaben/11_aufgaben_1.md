# Vererbung

## 1. Bücherschrank
**Aufgabenstellung:** Simulieren Sie einen Bücherschrank mit 4 gelesenen Büchern.

#### Schritte
1. Erstellen Sie zwei Klassen, die von der Klasse [Buch](Buch/Buch.java) erben:
	1. Kinderbuch: besitzt ein zusätzliches Attribut für die Altersfreigabe
	2. Sachbuch: besitzt ein zusätzliches Attribut für das Fachgebiet
2. Schreiben Sie folgendes Java-Programm:
	1. Befüllen Sie einen Bücherschrank mit 3 gelesenen Büchern: 1 Roman, 1 Kinderbuch und 1 Sachbuch.
	2. Geben Sie alle Bücher im Schrank nacheinander aus.
	3. Berechnen Sie die Gesamtzahl an gelesenenen Seiten und geben diese aus.

## 2. Lustiges Taschenbuch
**Aufgabenstellung:** Erweitern Sie das Paket aus Aufgabe 1 so, dass es eine finale Klasse `LustigesTaschenbuch` gibt, die von `Buch` abgeleitet ist.

#### Schritte
1. Die Klasse besitzt ein Attribut für die Nummer. Auf dieses Attribut kann nur lesend und nur aus der Klasse heraus zugegriffen werden.
2. Erstellen Sie einen passenden Konstruktor.
3. Zusätzlich gibt es eine Methode `lesen()`, die ausgibt, welches LTB mit welcher Nummer gelesen wird.
4. Passen Sie das Programm aus Aufgabe 1 so an, dass der Bücherschrank nun auch ein LTB enthält.
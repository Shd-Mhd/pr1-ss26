package Zoo;

public class Tier {
	protected String bezeichnung;

	public Tier() {
		this.bezeichnung = "Das Tier";
	}

	public void fressen() {
		System.out.println(this.bezeichnung + " frisst.");
	}
}

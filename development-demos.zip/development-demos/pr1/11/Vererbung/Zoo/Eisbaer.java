package Zoo;

public class Eisbaer extends Tier {

	Eisbaer() {
		this.bezeichnung = "Der Eisbär";
	}

	public void schwimmen() {
		System.out.println(this.bezeichnung + " schwimmt.");
	}

	@Override
	public void fressen(){
		System.out.println(this.bezeichnung + " frisst Fisch.");
	}
}

package Zoo;

public class Application {
	public static void main(String[] args) {
		Tier tier = new Tier();
		tier.fressen();
		Eisbaer eisbaer = new Eisbaer();
		eisbaer.fressen();
		eisbaer.schwimmen();
		Loewe loewe = new Loewe();
		loewe.fressen();
		loewe.bruellen();
	}
}

package Zoo;

public class Loewe extends Tier{
	Loewe() {
		this.bezeichnung = "Der Löwe";
	}

	public void bruellen() {
		System.out.println(this.bezeichnung + " brüllt.");
	}

	@Override
	public void fressen(){
		System.out.println(this.bezeichnung + " frisst Fleisch.");
	}
}

package Lampen;

public class Application {
	public static void main(String[] args) {
		System.out.println("=== Lampe ===");
		Lampe l = new Lampe();
		l.setEingeschaltet(true);
		System.out.println("Angeschaltet: "+ l.isEingeschaltet());
		l.setEingeschaltet(false);
		System.out.println("Angeschaltet: "+ l.isEingeschaltet());

		System.out.println("=== Dimmbare Lampe ===");
		DimLampe dl = new DimLampe();
		dl.beruehreTouchfeld();
		System.out.println("Angeschaltet: "+ dl.isEingeschaltet()+ " Stufe: " + dl.getStufe());
		dl.beruehreTouchfeld();
		dl.beruehreTouchfeld();
		System.out.println("Angeschaltet: "+ dl.isEingeschaltet()+ " Stufe: " + dl.getStufe());
		dl.beruehreTouchfeld();
		System.out.println("Angeschaltet: "+ dl.isEingeschaltet()+ " Stufe: " + dl.getStufe());
	}
}

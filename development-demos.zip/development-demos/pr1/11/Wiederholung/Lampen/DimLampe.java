package Lampen;

public class DimLampe {
	private short stufe;
	private boolean eingeschaltet;
	private final short MAX_STUFE = 3;

	public DimLampe() {
		this.stufe = 0;
		this.eingeschaltet = false;
	}

	public short getStufe() {
		return this.stufe;
	}

	public void beruehreTouchfeld() {
		short neueStufe = (short) (this.stufe + 1);
		if (neueStufe <= MAX_STUFE) {
			this.stufe = neueStufe;
			this.eingeschaltet = true;
		} else {
			this.stufe = 0;
			this.eingeschaltet = false;
		}
	}

	public boolean isEingeschaltet() {
		return this.eingeschaltet;
	}
}

package Lampen;

public class Lampe {
	private boolean eingeschaltet;

	public Lampe() {
		this.eingeschaltet = false;
	}

	public boolean isEingeschaltet() {
		return eingeschaltet;
	}

	public void setEingeschaltet(boolean wert) {
		eingeschaltet = wert;
	}
}

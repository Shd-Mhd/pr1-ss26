# Sichtbarkeit

## 1. Sparschwein
**Aufgabenstellung:** Erstellen Sie eine einfache Java‑Klasse `Sparschwein`, die einen Geldbetrag verwaltet.

#### Schritte
1. Legen Sie ein Attribut `inhalt` an, das den aktuellen Geldbetrag im Sparschwein speichert. Der Wert darf nur innerhalb der Klasse verändert werden. Warum ist das sinnvoll?
2. Die Methode `getInhalt()`soll den aktuellen Inhalt zurückgeben.
3. Die Methode `einzahlen(double betrag)` soll Geld hinzufügen. Negative Beträge dürfen nicht akzeptiert werden.
4. Initialisieren Sie das Sparschwein mit einem Startwert von 0 Euro im Konstruktor.
5. Schreiben die ein Java-Programm, um Ihre Klasse zu testen:
	1. Erstellen Sie ein Sparschwein‑Objekt.
	2. Zahlen Sie mehrere Beträge ein.
	3. Geben Sie nach jeder Einzahlung den aktuellen Inhalt in der Konsole aus.

## 2. Lampe
**Aufgabenstellung:** Erstellen Sie eine Java‑Klasse `Lampe`, die eine einfache Lampe modelliert.

#### Schritte
1. Legen Sie ein Attribut `eingeschaltet` an, das anzeigt, ob die Lampe aktuell an- oder ausgeschaltet ist (Status). Der Wert darf nur innerhalb der Klasse verändert werden.
2. Die Methode `isEingeschaltet()` soll den Status zurückgeben.
3. Die Methode `setEingeschaltet(boolean wert)` soll die Lampe an- oder ausschalten.
4. Beim Erzeugen ist die Lampe immer ausgeschaltet.
5. Schreiben die ein Java-Programm, um Ihre Klasse zu testen:
	1. Erstellen Sie ein Lampen-Objekt.
	2. Schalten Sie sie nacheinander an und aus und geben den aktuellen Status in der Konsole aus.

## 2. Dimmbare Lampe
**Aufgabenstellung:** Erstellen Sie eine Java‑Klasse `DimLampe`, die eine dimmbare Lampe modelliert.

#### Schritte
1. Legen Sie ein Attribut `eingeschaltet` an, das anzeigt, ob die Lampe aktuell an- oder ausgeschaltet ist (Status). Der Wert darf nur innerhalb der Klasse verändert werden.
2. Legen Sie ein Attribut `stufe` an, das die aktuelle Dimm-Stufe der Lampe anzeigt. Die maximale Stufe ist 3. Der Wert darf nur innerhalb der Klasse verändert werden.
3. Die Methode `isEingeschaltet()` soll den Status zurückgeben.
4. Die Methode `beruehreTouchfeld()` soll die aktuelle Dimm-Stufe der Lampe erhöhen.
	a. Falls dadurch die Maximalstufe überstiegen wurde, wird die Stufe auf 0 zurückgesetzt und die Lampe ausgeschaltet.
	b. Falls die Stufe größer 0 ist, wird die Lampe eingeschaltet.
4. Beim Erzeugen ist die Stufe immer 0 und die Lampe ist ausgeschaltet.
5. Schreiben die ein Java-Programm, um Ihre Klasse zu testen:
	1. Erstellen Sie ein Objekt Ihrer dimmbaren Lampe.
	2. Berühren Sie nacheinander das Touchfeld und geben den aktuellen Status und die Stufe in der Konsole aus.
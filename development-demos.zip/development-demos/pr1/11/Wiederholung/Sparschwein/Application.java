package Sparschwein;

public class Application {
	public static void main(String[] args) {
		Sparschwein s = new Sparschwein();
		s.einzahlen(15.50);
		System.out.println(s.getInhalt());
		s.einzahlen(0.50);
		System.out.println(s.getInhalt());
	}
}

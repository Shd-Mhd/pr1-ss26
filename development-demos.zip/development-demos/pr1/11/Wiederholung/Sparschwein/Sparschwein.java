package Sparschwein;

public class Sparschwein {

    private double inhalt;

    public Sparschwein() {
        this.inhalt = 0.0;
    }

    public double getInhalt() {
        return inhalt;
    }

    public void einzahlen(double betrag) {
        if (betrag < 0) {
            System.out.println("Betrag darf nicht negativ sein.");
        }
        inhalt += betrag;
    }
}
import java.util.Scanner;

public class CoinMachine {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Geben Sie einen Geldbetrag ein: ");
		double geldbetrag = scanner.nextDouble();
		int geldbetragInCent = (int) (geldbetrag * 100);
		int restBetrag = geldbetragInCent;

		int anzahl200 = geldbetragInCent / 200;
		restBetrag %= 200;
		int anzahl100 = restBetrag / 100;
		restBetrag %= 100;
		int anzahl50 = restBetrag / 50;
		restBetrag %= 50;
		int anzahl20 = restBetrag / 20;
		restBetrag %= 20;
		int anzahl10 = restBetrag / 10;
		restBetrag %= 10;
		int anzahl5 = restBetrag / 5;
		restBetrag %= 5;
		int anzahl2 = restBetrag / 2;
		restBetrag %= 2;
		int anzahl1 = restBetrag;

		System.out.println("2€: " + anzahl200);
		System.out.println("1€: " + anzahl100);
		System.out.println("0,5€: " + anzahl50);
		System.out.println("0,2€: " + anzahl20);
		System.out.println("0,1€: " + anzahl10);
		System.out.println("0,05€: " + anzahl5);
		System.out.println("0,02€: " + anzahl2);
		System.out.println("0,01€: " + anzahl1);
		scanner.close();
	}
}

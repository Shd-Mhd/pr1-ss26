import java.util.Scanner;

public class Domino {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Geben Sie zwei Zahlen zwischen 0 und 99 ein: ");
		System.out.print("Zahl 1: ");
		int eingabeZ1 = scanner.nextInt();
		System.out.print("Zahl 2: ");
		int eingabeZ2 = scanner.nextInt();

		int z1 = eingabeZ1 % 100;
		int z2 = eingabeZ2 % 100;

		int ersteZifferZ1 = z1 / 10;
		int zweiteZifferZ1 = z1 % 10;
		int ersteZifferZ2 = z2 / 10;
		int zweiteZifferZ2 = z2 % 10;

		boolean gemeinsameZiffer = 
			(ersteZifferZ1 == ersteZifferZ2) || 
			(ersteZifferZ1 == zweiteZifferZ2) || 
			(zweiteZifferZ1 == ersteZifferZ2) || 
			(zweiteZifferZ1 == zweiteZifferZ2);

		System.out.println("Können die Dominosteine aneinandergelegt werden: " + gemeinsameZiffer);

		scanner.close();
	}
}

public class FlowerArt {
	public static void main(String[] args) {

		// Einfache Zeichenliterale
		char slash = '/';
		char pipe = '|';

		// Escape-Zeichen
		char backslash = '\\';
		char newline = '\n';
		char tab = '\t';

		// Unicode-Zeichen (Blütenblatt + Herz)
		char petal = '\u273F'; // ✿
		char heart = '\u2665'; // ♥

		System.out.print("Eine Frühlingsblume:" + newline);
		System.out.println("" + tab + " " + petal + petal + petal + " " + tab);
		System.out.println("" + "      " + petal + "   " + heart + "   " + petal);
		System.out.println("" + tab + " " + petal + petal + petal + " " + tab);
		System.out.println("" + tab + " " + " " + pipe + " " + " " + tab);
		System.out.println("" + tab + backslash + " " + pipe + " " + slash + " " + tab);
		System.out.println("" + tab + " " + backslash + pipe + slash + " " + tab);
		System.out.println("" + tab + " " + " " + pipe + " " + " " + tab);

	}
}

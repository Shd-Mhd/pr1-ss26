import java.util.Scanner;

public class Flaschen {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.print("Gesamtanzahl der Flaschen: ");
		int flaschenAnzahl = scanner.nextInt();

		int captain = flaschenAnzahl / 2;
		int crew = flaschenAnzahl - captain;

		System.out.println("Flaschen für den Captain: " + captain);

		System.out.println("Flaschen für die Crew-Mitglieder: " + crew);

		System.out.print("Anzahl der Crew-Mitglieder: ");
		int crewAnzahl = scanner.nextInt();
		boolean fair = (crew % crewAnzahl == 0);

		System.out.println("Können die restlichen Flaschen gerecht verteilt werden? " + fair);
		
		scanner.close();
	}
}

# Variablen und Operatoren

## 1. Zeichenliterale: Flower-Art

**Aufgabenstellung:** Bauen Sie folgende Frühlingsblume aus Zeichenliteralen in einem Java-Programm:

		 ✿✿✿
	  ✿   ♥   ✿
		 ✿✿✿
		  │
		\ │ /
		 \│/
		  │

Folgende Zeichenliterale können Sie verwenden: 

```java
	// Einfache Zeichenliterale
	char slash = '/';
	char pipe = '|';
	char dash = '-';
	char dot = '.';

	// Escape-Zeichen
	char backslash = '\\';
	char newline = '\n';
	char tab = '\t';

	// Unicode-Zeichen (Blütenblatt + Herz)
	char petal = '\u273F'; // ✿
	char heart = '\u2665'; // ♥
```

## 2. Operatoren: Faire Aufteilung

**Aufgabenstellung:** Nach einem Piraten-Raubzug sollen die erbeuteten Flaschen gerecht aufgeteilt werden. Der Captain erhält grundsätzlich die Hälfte der Flaschen. Implementieren Sie ein Java-Programm, dass dem Captain bei der Aufteilung hilft.

#### Schritte
1. Schreiben Sie ein Programm, das die Gesamtzahl der erbeuteten Flaschen von der Kommandozeile einliest.
2. Geben Sie aus, wieviel der Captain davon bekommt.
3. Geben Sie aus, was für die Crew verbleibt.
4. Fragen Sie nach der Crew-Größe über die Kommandozeile.
5. Prüfen Sie, ob die Beute fair und gleich verteilt werden kann, sodass jedes Crew-Mitglied exakt die gleiche Anzahl Flaschen bekommt. Geben sie `true` oder `false` aus.

*Quelle:* "Captain CiaoCiao erobert Java – Das Trainingsbuch für besseres Java" von Christian Ullenboom.

## 3. Operatoren: Domino

**Aufgabenstellung:** Implementieren Sie eine Variante des *Anker-Domino-*Spiels: Alle Spielsteine haben zwei Felder mit Werten zwischne `0`und `9`. Ihr Java-Programm soll feststellen, ob zwei Steine, ggf. durch Rotation, so aneinandergelegt werden können, dass die beiden Felder die gleichen Werte haben.

#### Schritte
1. Schreiben Sie ein Programm, das zwei Zahlen einliest, wibei die Zahlen im Bereich von `0`bis `99`(beide Grenzen inklusive) liegen sollen.
2. Sind die Zahlen größer oder gleich `100`, sollen nur die letzten zwei Ziffern gewertet werden: `100` oder `200` wären dann wie `00` (also `0`), `1111` wäre wie `11`.
3. Teste, ob die beiden Zahlen eine gemeinsame Ziffer haben. Geben sie `true` oder `false` aus (nicht die gemeinsame Ziffer).

#### Beispiele
- `12` und `31` &rarr; true 
- `22` und `33` &rarr; false 

*Hinweis:* Ist die Zahl einstellig, steht vorne gedanklich eine `0`, sodas `01` und `20` ein gemeinsames Feld haben, nämlich `0`.

*Quelle:* "Captain CiaoCiao erobert Java – Das Trainingsbuch für besseres Java" von Christian Ullenboom.

## 4. Operatoren: Münzmaschine

**Aufgabenstellung:** Implementieren Sie eine Münzmaschine, die einen Geldbetrag in Euro-/Cent-Münzen ausgibt. 

#### Schritte
1. Schreiben Sie ein Programm, das einen Geldbetrag von der Kommandozeile einliest (Fließkommazahl).
2. Geben Sie aus, wie viele
	- 2-Euro-Münzen
	- 1-Euro-Münzen
	- 50-Cent-Münzen
	- 20-Cent-Münzen
	- 10-Cent-Münzen
	- 5-Cent-Münzen
	- 2-Cent-Münzen
	- 1-Cent-Münzen
	verwendet werden müssen, um den Geldbetrag mit Münzen auszuzahlen.
3. Die Formatierung der Ausgabe können Sie frei wählen.

*Quelle:* "Captain CiaoCiao erobert Java – Das Trainingsbuch für besseres Java" von Christian Ullenboom.
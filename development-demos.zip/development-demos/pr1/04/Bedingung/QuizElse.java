package Bedingung;

public class QuizElse {
	public static void main(String[] args) {
		if ( true ){
		if ( false )
		if ( 3!=4 )	
		;
		else
		System.out.println("Klabautermann");
		else
		System.out.println("Pumuckl");
		}
	}
}

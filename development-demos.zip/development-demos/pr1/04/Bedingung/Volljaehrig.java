package Bedingung;

public class Volljaehrig {
	public static void main(String[] args) {
		int alter = 17;
		String status = (alter >= 18) ? "volljährig" : "minderjährig";
		System.out.println(status);
	}
}

package Bedingung;

public class QuizIf {
	public static void main(String[] args) {
		// int x = 2;
		// int y = 1;
		// if (x > y) 
		// 	int swap = x;
		// 	x = y;
		// 	y = swap;
	}
}

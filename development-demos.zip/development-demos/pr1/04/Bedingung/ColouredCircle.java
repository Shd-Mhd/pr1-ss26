package Bedingung;
public class ColouredCircle {
	public static void main(String[] args) {
		double colourRand = Math.random();
		String colour;
		if (colourRand < 1.0 / 3) {
			colour = "red";
		} else if (colourRand < 2.0 / 3) {
			colour = "blue";
		} else {
			colour = "green";
		}

		System.out.println(
				"<svg height='400' width='400'>");
		System.out.println(
				" <circle cx='200' cy='200' r='100' fill='" + colour + "' />");
		System.out.println(
				"</svg>");
	}
}

package Bedingung;
import java.util.Scanner;

public class Zustimmung {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Antwort: ");
		String antwort = scanner.nextLine();
		switch (antwort) {
			case "Ay":
			case "Ay, ay":
			case "Ein Ei":
			case "yes":
			case "ja":
				System.out.println("Freut mich!");
				break;
			default:
				System.out.println("Schade.");
				break;
		}
		scanner.close();
	}
}

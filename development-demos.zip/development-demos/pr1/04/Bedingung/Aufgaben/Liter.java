import java.util.Scanner;

public class Liter {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Liter: ");
		double liter = scanner.nextDouble();
		if (liter >= 1.0) {
			System.out.println("ca. " + (int) liter + " l");
		} else if (liter >= 0.1) {
			System.out.println("ca. " + (int) (liter * 100) + " cl");
		} else if(liter >= 0.001){
			System.out.println("ca. " + (int) (liter * 1000) + " ml");
		}else{
			System.out.println("Wert zu klein: keine Ausgabe.");
		}
		scanner.close();
	}
}

import java.util.Scanner;

public class Zahltag {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		double schulden = 1000.0;
		double maxBetrag = schulden + (schulden * 0.2);
		double minBetrag = schulden - (schulden * 0.1);

		System.out.print("Rückzahlung: ");
		double betrag = scanner.nextDouble();

		if (betrag < minBetrag || betrag > maxBetrag) {
			System.out.println("Rückzahlung nicht akzeptiert!");
		} else {
			System.out.println("Rückzahlung akzeptiert.");
		}

		scanner.close();
	}
}

# Bedingte Anweisungen

## 1. If-Anweisung: Rückzahlung

**Aufgabenstellung:** Sie haben 1000€ Schulden bei einer Bank und wollen diese zurückzahlen. Die Bank bietet die Rückzahlung über einen speziellen Automaten an, der die Zahlung nur annimmt, wenn der Betrag höchstens 20% über dem Schuldenbetrag oder 20% unter dem Schuldenbetrag liegt. Schreiben Sie ein Java-Programm, dass den Rückzahlungsbetrag über die Konsole einliest und danach ausgibt, ob die Rückzahlung akzeptiert wurde. 

*Quelle:* "Captain CiaoCiao erobert Java – Das Trainingsbuch für besseres Java" von Christian Ullenboom.

## 2. If-else-if-Anweisung: Flüssigkeitsmengen

**Aufgabenstellung:** Schreiben Sie ein Java-Programm, das eine Flüssigkeitsmenge in Litern über die Konsole einliest und diese abhängig von einem Schema automatisch in die passende Einheit (Liter, Zentiliter oder Milliliter) umrechnet und ausgibt.

*Schema (von oben nach unten):*
- 1.0 und größer &rarr; Ausgabe in Liter (l)
- 0,1 und größer &rarr; Ausgabe in Zentiliter (cl)
- 0,001 und größer &rarr; Ausgabe in Milliliter (ml)

Zu kleine Werte sollen erkannt und in diesem Fall eine entsprechende Meldung angezeigt werden.

*Quelle:* "Captain CiaoCiao erobert Java – Das Trainingsbuch für besseres Java" von Christian Ullenboom.

## 3. Switch-Anweisung: Konsolenspiel

**Aufgabenstellung:** Implementieren Sie das Menü zu einem kleinen Computerspiel, das vier Optionen anzeigt:  
```
1 = Neues Spiel starten  
2 = Spiel laden  
3 = Einstellungen öffnen  
4 = Spiel beenden
```
Schreiben Sie ein Java‑Programm, das die Auswahl von der Kommandozeile ausliest, auswertet und je nach Zahl den passenden Text ausgibt. Denken Sie auch an eine Ausgabe für ungültige Eingaben.



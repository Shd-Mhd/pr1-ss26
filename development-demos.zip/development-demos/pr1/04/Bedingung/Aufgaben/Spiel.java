import java.util.Scanner;

public class Spiel {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int auswahl = scanner.nextInt();
		switch (auswahl) {
			case 1:
				System.out.println("Neues Spiel starten");
				break;
			case 2:
				System.out.println("Spiel laden");
				break;
			case 3:
				System.out.println("Einstellungen öffnen");
				break;
			case 4:
				System.out.println("Beenden");
				break;
			default:
				System.out.println("Ungültige Auswahl");
		}
		scanner.close();
	}
}

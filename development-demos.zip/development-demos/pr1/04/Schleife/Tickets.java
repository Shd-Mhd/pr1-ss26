package Schleife;

public class Tickets {
	public static void main(String[] args) {
		int tickets = 3;
		while (tickets > 0) {
			System.out.println("Ticket wurde verkauft. Noch übrig: " + tickets);
			tickets--;
		}
	}
}

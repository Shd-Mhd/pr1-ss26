package Schleife;

public class QuizFor {
	public static void main(String[] args) {
		for (int stars = 0; stars <= 7; stars = stars + 2) {
			System.out.println("***");
		}
		for (int hash = 10; hash < 0; hash++) {
			System.out.println("##");
		}
	}
}

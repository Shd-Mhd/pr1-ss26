package Schleife;

import java.util.Scanner;

public class Passwort {
	public static void main(String[] args) {
		String eingabe;
		String korrekt = "geheim";
		Scanner scanner = new Scanner(System.in);
		do {
			eingabe = scanner.nextLine();
			System.out.println("Passwort prüfen...");
		} while (!eingabe.equals(korrekt));
		System.out.println("Passwort korrekt.");
		scanner.close();
	}
}

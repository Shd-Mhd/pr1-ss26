package KonstruktorFragezeichen;

import java.util.Scanner;

public class GeschenkeFragezeichenKonstruktor {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Fragezeichen[] detektive = new Fragezeichen[3];

		detektive[0] = new Fragezeichen("Justus", "Jonas", "1.4.1950");
		detektive[1] = new Fragezeichen("Bob", "Andrews", "11.9.1950");
		detektive[2] = new Fragezeichen("Peter", "Shaw", "17.6.1950");

		for (Fragezeichen aktuellerDetektiv : detektive) {
			aktuellerDetektiv.zumGeburtstagGratulieren(scanner);
		}
		scanner.close();
	}
}

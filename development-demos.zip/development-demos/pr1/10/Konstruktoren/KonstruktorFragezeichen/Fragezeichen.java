package KonstruktorFragezeichen;

import java.util.Scanner;

class Fragezeichen {
	String vorname;
	String nachname;
	String geburtstag;

	Fragezeichen(String vorname, String nachname, String geburtstag) {
		this.vorname = vorname;
		this.nachname = nachname;
		this.geburtstag = geburtstag;
	}

	void zumGeburtstagGratulieren(Scanner scanner) {
		System.out.print("Ist heute der " + geburtstag + "? ");
		boolean hatGeburtstag = scanner.nextBoolean();
		if (hatGeburtstag) {
			System.out.println(
					"Happy Birthday, " + vorname + " " + nachname + "!");
		}
	}
}

package Euro;

public class Application {
	public static void main(String[] args) {
		Euro joghurt = new Euro(1,99);
		Euro duplo = new Euro(79);
		Euro sandwich = new Euro(3,50);

		Euro summe = joghurt.addiere(sandwich).addiere(duplo);

		System.out.println(summe.ausgabeString());
	}
}

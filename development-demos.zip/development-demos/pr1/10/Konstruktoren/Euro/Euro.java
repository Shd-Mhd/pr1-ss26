package Euro;

public class Euro {
	int cent;

	Euro(int euro, int cent){
		this.cent = euro * 100 + cent;
	}
	Euro(int cent) {
		this(0, cent);
	}

	Euro addiere(Euro betrag){
		return new Euro(this.cent + betrag.cent);
	}
	Euro subtrahiere(Euro betrag){
		return new Euro(this.cent - betrag.cent);
	}

	public String ausgabeString(){
		return (cent/100) + "," + (cent%100) + " €";
	}
}

# Konstruktoren

## 1. Zugticket
**Aufgabenstellung:** Erstellen sie eine Java-Klasse `Zugticket`, die Start- und Zielbahnhof, Reisedatum (als `String`) und einen reservierten Sitzplatz (als `String`) verwaltet. 

#### Schritte
1. Die Klasse soll 3 unterschiedliche Konstruktoren zur Verfügung stellen. Dabei müssen Start- und Zielbahnhof immer gesetzt werden.
2. Überlegen Sie sich geeignete Standardwerte für Reisedatum und Sitzplatz.
3. Ergänzen Sie eine Methode `anzeigen()`, um das Zugticket geeignet in der Konsole auszugeben.
4. Schreiben Sie ein Java-Programm, welches alle Konstruktoren Ihrer Klasse einmal aufruft und jeweils die erzeugte Instanz in der Konsole ausgibt.

## 2. Blumenstrauß

**Aufgabenstellung:** Erstellen Sie eine Java-Klasse `Blumenstrauss`, mit der verschiedene Blumensträuße modelliert werden können. 

#### Schritte
1. Die Klasse soll folgende Eigenschaften besitzen: 
- Hauptblume
- Anzahl der Blumen
- Anlass
- Schleife (ja/nein)
- *automatisch* berechneter Preis
2. Implementieren Sie mehrere Konstruktoren, sodass ein Standardstrauß sowie individuell konfigurierte Sträuße erzeugt werden können. 
3. Der Standardstrauß enthält immer 5 Exemplare der Hauptblume, trägt den Anlass "Allgemein" und hat keine Schleife.
4. Der Preis soll abhängig von der Blumenart, der Anzahl und der optionalen Schleife berechnet werden:
- Preise pro Blume
	- Rose: 1,50 € pro Blume
	- Dahlie: 0,50 € pro Blume
	- Lilie: 2,00 € pro Blume
- Preis für Schleife: + 0,50 €
5. Es soll eine Methode `anzeigen()` vorhanden sein, die alle Daten des Straußes übersichtlich ausgibt.
6. Schreiben Sie ein Java-Programm, welches die Erstellung eines Blumenstraußes steuert.
	1. Abfrage der Hauptblume: Benutzer:in soll eingeben, welche Hauptblume der Strauß enthalten soll. Erlaubt sind ausschließlich Rose, Dahlie und Lilie. Bei einer anderen Eingabe soll eine Fehlermeldung ausgegeben werden.
	2. Abfrage, ob ein Standardstrauß gewünscht ist:
		- Wenn ja, wird ein Standardstrauß mit der gewählten Blume erzeugt.
		- Wenn nein, folgen weitere Eingaben zum individuellen Strauß:
			- Abfrage der Anzahl der Blumen (nur positive Werte zulassen).
			- Abfrage, ob es einen Anlass gibt:
				- Wenn ja: Anlass als Text einlesen und zusätzlich abfragen, ob der Strauß mit Schleife versehen werden soll.
	◦ 			- Wenn kein Anlass angegeben wird, soll der Strauß nur mit Hauptblume und Anzahl erzeugt werden.
	3. Ausgabe: Wenn ein gültiger Strauß erzeugt wurde, soll die Methode `anzeigen()` aufgerufen werden, um alle Daten inklusive Preis auszugeben.

## 3. Lernkarten

**Aufgabenstellung:** Erstellen Sie ein Java‑Programm, mit dem einfache Lernkarten verwaltet und in einem kleinen Training abgefragt werden können.

#### Schritte
1. Implementieren Sie die Klasse `Lernkarte` mit folgenden Eigenschaften:
	- Frage
	- Antwort
	- Fach (Standard: „Allgemein“)
	- Schwierigkeitsstufe (Standard: 1)
2. Erstellen Sie mehrere Konstruktoren:
	1. Konstruktor mit Frage und Antwort (Fach = „Allgemein“, Schwierigkeit = 1)
	2. Konstruktor mit Frage, Antwort und Fach (Schwierigkeit = 1)
	3. Vollständiger Konstruktor mit allen vier Eigenschaften
3. Es soll eine Methode `anzeigen()` vorhanden sein, die die Lernkarte in folgendem Format ausgibt:
`[Fach | Stufe X] Frage`
4. Es soll eine Methode `holeAntwort()` vorhanden sein, die die gespeicherte Antwort zurückliefert.
5. Implementieren Sie die Klasse `Trainer`, welche ein kleines Array aus drei Lernkarten verwaltet und ein Training durchführt. Folgende Methoden sollten vorhanden sein:
	- Karte hinzufügen: Fügt eine Lernkarte an der angegebenen Position/Index ein (falls möglich).
	- Training starten :
		1. Gibt jede gespeicherte Lernkarte aus
		2. Fragt den/die Benutzer:in nach der Antwort
		3. Vergleicht Eingabe und richtige Antwor
		4. Gibt Rückmeldung „Richtig“ oder „Falsch + richtige Antwort“
		5. Beendet das Training nach allen Karten
5. Schreiben Sie ein Java-Programm, welches ein Training testweise startet:
	1. Erzeugen eines Trainer-Objekts.
	2. Legen Sie drei Lernkarten an:
		- Eine mit Standardwerten
		- Eine mit Fachangabe
		- Eine mit Fach und Schwierigkeitsstufe
	3. Fügen Sie die Karten in den Trainer ein.
	4. Starten Sie das Training.
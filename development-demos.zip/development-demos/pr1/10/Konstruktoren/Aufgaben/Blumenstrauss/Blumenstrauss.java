package Blumenstrauss;

public class Blumenstrauss {

	String hauptblume;
	int anzahl;
	String anlass;
	boolean mitSchleife;
	double preis;

	//Standard-Strauss
	Blumenstrauss(String hauptblume) {
		this(hauptblume, 5, "Allgemein", false);
	}

	Blumenstrauss(String hauptblume, int anzahl) {
		this(hauptblume, anzahl, "Allgemein", false);
	}

	Blumenstrauss(String hauptblume, int anzahl, String anlass, boolean mitSchleife) {
		this.hauptblume = hauptblume;
		this.anzahl = anzahl;
		this.anlass = anlass;
		this.mitSchleife = mitSchleife;
		preisBerechnen();
	}

	void anzeigen() {
		System.out.println(this.anzahl + "× " + this.hauptblume +
				" | Anlass: " + this.anlass +
				" | Schleife: " + (this.mitSchleife ? "ja" : "nein") + "-> " + this.preis + " €");
	}

	void preisBerechnen() {
		this.preis = this.mitSchleife ? 0.5 : 0.0;
		switch (this.hauptblume) {
			case "Rose":
				this.preis += this.anzahl * 1.5;
				break;
			case "Dahlie":
				this.preis += this.anzahl * 0.5;
				break;
			case "Lilie":
				this.preis += this.anzahl * 2.0;
				break;
			default:
				this.preis = 1.0;
		}
	}
}

package Blumenstrauss;

import java.util.Scanner;

public class Application {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Blumenstrauss strauss = null;

		System.out.print("Welche Blume soll Ihr Strauss enthalten? ");
		String blume = scanner.nextLine();
		if (blume.equals("Rose") || blume.equals("Dahlie") || blume.equals("Lilie")) {
			System.out.print("Soll es ein Standardstrauss werden? ");
			boolean standard = scanner.nextBoolean();
			scanner.nextLine();
			if (standard) {
				strauss = new Blumenstrauss(blume);
			} else {
				System.out.print("Wie viele Blumen soll Ihr Strauss enthalten? ");
				int anzahl = scanner.nextInt();
				scanner.nextLine();
				if (anzahl > 0) {
					System.out.print("Gibt es einen Anlass? ");
					boolean gibtAnlass = scanner.nextBoolean();
					scanner.nextLine();
					if (gibtAnlass) {
						System.out.print("Zu welchem Anlass brauchen Sie den Strauss? ");
						String anlass = scanner.nextLine();
						System.out.print("Soll Ihr Strauss mit einer Schleife verziert werden? ");
						boolean schleife = scanner.nextBoolean();
						strauss = new Blumenstrauss(blume, anzahl, anlass, schleife);
					} else {
						strauss = new Blumenstrauss(blume, anzahl);
					}
				}
			}
		} else {
			System.out.println("Es sind nur Rosen, Dahlien und Lilien erlaubt.");
		}

		if (strauss != null) {
			strauss.anzeigen();
		}

		scanner.close();
	}
}

package Lernkarte;

import java.util.Scanner;

public class Trainer {
	Lernkarte[] karten = new Lernkarte[3];
	Scanner scanner;

	Trainer(Scanner scanner) {
		this.scanner = scanner;
	}

	void karteHinzufuegen(Lernkarte karte, int index) {
		if (index < karten.length) {
			karten[index] = karte;
			System.out.println("Neue Karte hinzugefügt.");
		} else {
			System.out.println("Karte konnte nicht hinzugefügt werden.");
		}
	}

	void trainingStarten() {
		System.out.println("=== Lernkarten-Training ===");

		for (Lernkarte k : karten) {
			if (k != null) {
				k.anzeigen();
				System.out.print("Antwort eingeben: ");
				String eingabe = scanner.nextLine();

				if (eingabe.equals(k.holeAntwort())) {
					System.out.println("Richtig!");
				} else {
					System.out.println("Falsch. Richtige Antwort: " + k.holeAntwort());
				}
			}
		}

		System.out.println("Training beendet.");
	}
}

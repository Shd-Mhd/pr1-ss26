package Lernkarte;

import java.util.Scanner;

public class Application {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Trainer trainer = new Trainer(scanner);

		Lernkarte k1 = new Lernkarte("Mit welcher Währung zahlt man in Italien?", "Euro");
		trainer.karteHinzufuegen(k1, 0);
		Lernkarte k2 = new Lernkarte("Was ist die Abkürzung für Objektorientierte Programmierung?", "OOP", "Informatik");
		trainer.karteHinzufuegen(k2, 1);
		Lernkarte k3 = new Lernkarte("Was ist H2O?", "Wasser", "Chemie", 2);
		trainer.karteHinzufuegen(k3, 2);

		trainer.trainingStarten();
		scanner.close();
	}

}

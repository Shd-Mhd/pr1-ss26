package Lernkarte;

public class Lernkarte {

	String frage;
	String antwort;
	String fach;
	int schwierigkeit;

	Lernkarte(String frage, String antwort) {
		this(frage, antwort, "Allgemein", 1);
	}

	Lernkarte(String frage, String antwort, String fach) {
		this(frage, antwort, fach, 1);
	}

	Lernkarte(String frage, String antwort, String fach, int schwierigkeit) {
		this.frage = frage;
		this.antwort = antwort;
		this.fach = fach;
		this.schwierigkeit = schwierigkeit;
	}

	void anzeigen() {
		System.out.println("[" + fach + " | Stufe " + schwierigkeit + "] " + frage);
	}

	String holeAntwort(){
		return antwort;
	}

}

package Zugticket;

public class Application {
	public static void main(String[] args) {
		final String START = "Mannheim";
		Zugticket ticket1 = new Zugticket(START, "Freiburg");
		ticket1.anzeigen();
		Zugticket ticket2 = new Zugticket(START, "Hamburg", "25-06-2026");
		ticket2.anzeigen();
		Zugticket ticket3 = new Zugticket(START, "Saarbrücken", "10-11-2026", "104");
		ticket3.anzeigen();
		ticket3.start ="Test";
	}
}

package Zugticket;

public class Zugticket {

	String start;
	String ziel;
	String datum;
	String sitzplatz;

	Zugticket(String start, String ziel) {
		this(start, ziel, "1-1-2026", "frei");
	}

	Zugticket(String start, String ziel, String datum) {
		this(start, ziel, datum, "frei");
	}

	Zugticket(String start, String ziel, String datum, String sitzplatz) {
		this.start = start;
		this.ziel = ziel;
		this.datum = datum;
		this.sitzplatz = sitzplatz;
	}

	void anzeigen() {
		System.out.println("Ticket: " + start + " → " + ziel +
				" am " + datum + ", Sitzplatz: " + sitzplatz);
	}

}

package Student;

public class Student {

	private String name;
	// private final: unveränderlich nach der Erzeugung
	private final int matrikelnummer;
	private int aktuellesSemester;
	private int anzahlCredits;

	public Student(String name, int matrikelnummer) {
		setName(name);
		this.matrikelnummer = matrikelnummer; // final → muss hier gesetzt werden
		this.aktuellesSemester = 1;
		this.anzahlCredits = 0;
	}

	public String getName() {
		return name;
	}

	public void setName(String neuerName) {
		if (neuerName == null || neuerName.isBlank()) {
			throw new IllegalArgumentException("Name darf nicht leer sein.");
		}
		this.name = neuerName;
	}

	public int getMatrikelnummer() {
		return matrikelnummer;
	}

	public int getAktuellesSemester() {
		return aktuellesSemester;
	}

	public void erhoeheSemester() {
		aktuellesSemester++;
	}

	public int getAnzahlCredits() {
		return anzahlCredits;
	}

	public void fuegeCreditsHinzu(int credits) {
		if (credits <= 0) {
			throw new IllegalArgumentException("Credits müssen positiv sein.");
		}
		anzahlCredits += credits;
	}

	public String druckeInfos() {
		return this.name + " (" + this.matrikelnummer + "): " + this.aktuellesSemester + ". Semester, "
				+ this.anzahlCredits + " ECTS";
	}
}

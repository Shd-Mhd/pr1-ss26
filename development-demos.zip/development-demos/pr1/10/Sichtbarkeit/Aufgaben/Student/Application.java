package Student;

public class Application {
	public static void main(String[] args) {
		Student anna = new Student("Anna", 300561828);
		System.out.println(anna.druckeInfos());
		anna.fuegeCreditsHinzu(30);
		System.out.println(anna.druckeInfos());
		anna.setName("Anna Garcia");
		System.out.println(anna.druckeInfos());
		anna.erhoeheSemester();
		anna.fuegeCreditsHinzu(20);
		System.out.println(anna.druckeInfos());
	}
}

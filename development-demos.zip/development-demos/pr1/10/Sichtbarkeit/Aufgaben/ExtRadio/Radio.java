package ExtRadio;

public class Radio {
	private boolean isOn;
	private int lautstaerke;

	public Radio(boolean isOn, int lautstaerke) {
		this.isOn = isOn;
		lautstaerkeAendern(lautstaerke);
	}

	public int getLautstaerke() {
		return this.lautstaerke;
	}

	private void lautstaerkeAendern(int wert) {
		int neueLautstaerke = lautstaerke + wert;
		if (neueLautstaerke < 0) {
			neueLautstaerke = 0;
		} else if (neueLautstaerke > 100) {
			neueLautstaerke = 100;
		}
		lautstaerke = neueLautstaerke;
	}

	public void lautstaerkeErhoehen() {
		lautstaerkeAendern(1);
	}

	public void lautstaerkeVerringern() {
		lautstaerkeAendern(-1);
	}

	public void anschalten() {
		isOn = true;
	}

	public void ausschalten() {
		isOn = false;
	}

	public String ausgabeString() {
		return "Radio[laustärke=" + lautstaerke + ", " + (isOn ? "an" : "aus") + "]";
	}
}

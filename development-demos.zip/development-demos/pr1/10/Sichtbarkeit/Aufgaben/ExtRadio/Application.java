package ExtRadio;

public class Application {
	public static void main(String[] args) {
		Radio omasRadio = new Radio(true, 12);
		Radio opasRadio = new Radio(true, 15);

		System.out.println("--- Omas Radio ---");
		System.out.println("Initiale Lautstärke: " + omasRadio.getLautstaerke());
		omasRadio.lautstaerkeErhoehen();
		omasRadio.lautstaerkeErhoehen();
		System.out.println(omasRadio.ausgabeString());

		omasRadio.lautstaerkeVerringern();
		System.out.println(omasRadio.ausgabeString());

		omasRadio.ausschalten();
		System.out.println(omasRadio.ausgabeString());

		System.out.println("--- Opas Radio ---");
		System.out.println("Initiale Lautstärke: " + opasRadio.getLautstaerke());
		omasRadio.lautstaerkeErhoehen();
		omasRadio.lautstaerkeErhoehen();
		System.out.println(opasRadio.ausgabeString());
	}
}

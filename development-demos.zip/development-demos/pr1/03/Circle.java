public class Circle {
	public static void main(String[] args){
		int x = 50;
		int y = 70;
		double radius = 10 + Math.random() * 10;

		System.out.println(
			"<svg height='400' width='1000'>"
		);
		System.out.println(
			" <circle cx='" + x + "' cy='" + y + "' r='" + radius + "' />"
		);
		System.out.println(
			"</svg>"
		);
	}
}

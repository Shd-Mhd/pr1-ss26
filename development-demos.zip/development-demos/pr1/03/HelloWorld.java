public class HelloWorld {
	public static void main(String[] args) {
		System.out.println("\u2665Hallöchen Studierende der Programmierung 1!\u2665");
	}
}
import java.util.Scanner;

public class ConsoleIO {
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		double wert = scanner.nextDouble();
		System.out.println("Es wurde " +  wert + " eingegeben.");
		scanner.close();
	}
}

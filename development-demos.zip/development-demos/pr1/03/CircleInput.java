import java.util.Scanner;

public class CircleInput {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Geben Sie die x-Koordinate des Kreismittelpunkts an: ");
		int x = scanner.nextInt();
		System.out.print("Geben Sie die y-Koordinate des Kreismittelpunkts an: ");
		int y = scanner.nextInt();
		System.out.print("Geben Sie die y-Koordinate des Kreismittelpunkts an: ");
		double radius = scanner.nextDouble();

		System.out.println(
				"<svg height='400' width='1000'>");
		System.out.println(
				" <circle cx='" + x + "' cy='" + y + "' r='" + radius + "' />");
		System.out.println(
				"</svg>");

		scanner.close();
	}
}

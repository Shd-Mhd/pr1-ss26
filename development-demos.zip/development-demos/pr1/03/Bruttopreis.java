import java.util.Scanner;

public class Bruttopreis {
	public static void main(String[] args){

		double ustSatz = 19.0;
		double ustFaktor = 1.0 + ustSatz / 100.0;

		Scanner scanner = new Scanner(System.in);
		System.out.println("Bitte Nettopreis eingeben:");
		double nettoPreis = scanner.nextDouble();
		
		double bruttopreis = nettoPreis * ustFaktor;
		System.out.println("Bruttopreis ist: " + bruttopreis);

		scanner.close();
	}
}

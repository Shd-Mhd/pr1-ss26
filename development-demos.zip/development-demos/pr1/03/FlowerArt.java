public class FlowerArt {
	public static void main(String[] args) {

		// Einfache Zeichenliterale
		char slash = '/';
		char pipe = '|';
		char dash = '-';
		char dot = '.';

		// Escape-Zeichen
		char backslash = '\\';
		char newline = '\n';
		char tab = '\t';

		// Unicode-Zeichen (Blütenblatt + Herz)
		char petal = '\u273F'; // ✿
		char heart = '\u2665'; // ♥

		System.out.print("Eine kleine Blume:" + newline);
		System.out.println(tab + " " + dot + dot+ dot + dot + dot);
		System.out.println(tab + "  " + backslash + heart + slash);
		System.out.println(tab + "  " + slash + petal + backslash);
		System.out.println(tab + " " + slash + " " + petal + " " + backslash);
		System.out.println(tab + "  " + backslash + petal + slash);
		System.out.println(tab + "   " + pipe);
		System.out.println(tab + "   " + pipe);
		System.out.println(tab + "  " + dash + dash + dash);
	}
}

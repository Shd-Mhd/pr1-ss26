package Ticket;

public class Application {
	public static void main(String[] args) {
		Ticket t1 = new Ticket("Dortmund-Schalke");
		System.out.println("Neu: " + t1);
		System.out.println("\tZähler = " + Ticket.getZaehler());
		
		Ticket t2 = new Ticket("Hoffenheim-Leverkusen");
		System.out.println("Neu: " + t2);
		System.out.println("\tZähler = " + Ticket.getZaehler());
	}
}

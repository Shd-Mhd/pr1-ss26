package Ticket;

public class Ticket {
	public static int zaehler = 0;

	private int serienNummer;
	private String spiel;

	public Ticket(String spiel) {
		zaehler++;
		serienNummer = zaehler;
		this.spiel = spiel;
	}

	public static int getZaehler() {
		return zaehler;
	}

	@Override
	public String toString() {
		return "Ticket [serienNummer=" + serienNummer + ", spiel=" + spiel + "]";
	}

}

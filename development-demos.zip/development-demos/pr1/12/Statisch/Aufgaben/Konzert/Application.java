package Aufgaben.Konzert;

public class Application {
	public static void main(String[] args) {
		KonzertTicket ticket1 = new KonzertTicket("Sia", 500);
		KonzertTicket ticket2 = new KonzertTicket("Deine Freunde", 88);

		KonzertTicket.setPreisFaktor(2.0);
		
		System.out.println(ticket1);
		System.out.println(ticket2);

		System.out.println("Aktuell verkaufte Tickets: " + KonzertTicket.zaehler);
	}
}

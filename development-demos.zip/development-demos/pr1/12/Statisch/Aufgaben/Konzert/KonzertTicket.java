package Aufgaben.Konzert;

public class KonzertTicket {

	public static int zaehler = 0;
	private static double preisFaktor = 1.0;

	private int ticketNummer;
	private String bandName;
	private double grundPreis;

	public KonzertTicket(String bandname, double grundpreis) {
		this.bandName = bandname;
		this.grundPreis = grundpreis;
		this.ticketNummer = ++zaehler;
	}

	public static void setPreisFaktor(double faktor) {
		preisFaktor = faktor;
	}

	public double getEndpreis() {
		return this.grundPreis * preisFaktor;
	}

	@Override
	public String toString() {
		return "Nr. " + ticketNummer + ": Ticket für " + bandName + " -> " + getEndpreis() + " €";
	}
}

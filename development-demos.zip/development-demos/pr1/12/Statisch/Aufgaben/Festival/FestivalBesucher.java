package Aufgaben.Festival;

public class FestivalBesucher {

	private static int maxKapazitaet = 100;
	private static int anzRegistrierteBesucher = 0;

	private String name;
	private String wochentag;

	public FestivalBesucher(String name, String wochentag) {
		if (anzRegistrierteBesucher < maxKapazitaet) {
			this.name = name;
			this.wochentag = wochentag;
			anzRegistrierteBesucher++;
		} else {
			System.out.println("Keine Plätze mehr frei!");
		}
	}

	public String getWochentag() {
		return wochentag;
	}

	public static void setMaxKapazitaet(int kapazitaet) {
		maxKapazitaet = kapazitaet;
	}

	public static int getFreiePlaetze() {
		return maxKapazitaet - anzRegistrierteBesucher;
	}

	@Override
	public String toString() {
		return "FestivalBesucher [name=" + name + ", wochentag=" + wochentag + "]";
	}

}

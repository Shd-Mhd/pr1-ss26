package Aufgaben.Festival;

public class Application {
	public static void main(String[] args) {
		FestivalBesucher.setMaxKapazitaet(8);

		FestivalBesucher b1 = new FestivalBesucher("Tick", "Freitag");
		FestivalBesucher b2 = new FestivalBesucher("Trick", "Samstag");
		FestivalBesucher b3 = new FestivalBesucher("Track", "Freitag");
		FestivalBesucher b4 = new FestivalBesucher("Daisy", "Sonntag");
		FestivalBesucher b5 = new FestivalBesucher("Mini", "Freitag");

		System.out.println("Freie Plätze insgesamt: " + FestivalBesucher.getFreiePlaetze());

		// Auswertung nach Tagen
		int freitag = 0;
		int samstag = 0;
		int sonntag = 0;

		FestivalBesucher[] alle = { b1, b2, b3, b4, b5 };

		for (FestivalBesucher b : alle) {
			if (b == null)
				continue;

			switch (b.getWochentag()) {
				case "Freitag":
					freitag++;
					break;
				case "Samstag":
					samstag++;
					break;
				case "Sonntag":
					sonntag++;
					break;
			}
		}

		System.out.println("Besucher am Freitag: " + freitag);
		System.out.println("Besucher am Samstag: " + samstag);
		System.out.println("Besucher am Sonntag: " + sonntag);

	}
}

public class KonzertTicket {
    private int ticketnummer;
    private String bandname;
    private double grundpreis;

    private static double preisFaktor = 1.0;
    private static int anzahlTickets = 0;

    public KonzertTicket(String bandname, double grundpreis) {
        this.bandname = bandname;
        this.grundpreis = grundpreis;

        anzahlTickets++;
        this.ticketnummer = anzahlTickets;
    }

    public static void setPreisFaktor(double faktor) {
        preisFaktor = faktor;
    }

    public double getEndpreis() {
        return grundpreis * preisFaktor;
    }

    public static int getAnzahlTickets() {
        return anzahlTickets;
    }

    @Override
    public String toString() {
        return "Ticket-Nr.: " + ticketnummer +
               "\nBand: " + bandname +
               "\nGrundpreis: " + grundpreis + " €" +
               "\nEndpreis: " + getEndpreis() + " €";
    }

    public static void main(String[] args) {

        KonzertTicket.setPreisFaktor(1.2);

        KonzertTicket ticket1 = new KonzertTicket("Metallica", 80.0);
        KonzertTicket ticket2 = new KonzertTicket("Rammstein", 95.0);
        KonzertTicket ticket3 = new KonzertTicket("Coldplay", 70.0);

        System.out.println(ticket1);
        System.out.println();

        System.out.println(ticket2);
        System.out.println();

        System.out.println(ticket3);
        System.out.println();

        System.out.println("Insgesamt erstellte Tickets: "
                + KonzertTicket.getAnzahlTickets());
    }
}
# Statische Attribute und Methoden

## 1. Konzerttickets

**Aufgabenstellung:** Ein Veranstalter verkauft Tickets für verschiedene Konzerte. Jedes Ticket soll automatisch eine laufende Nummer erhalten. Außerdem gibt es einen Preisfaktor, der für alle Tickets gilt (z. B. wegen Servicegebühren).

#### Schritte 
1. Erstellen Sie eine Klasse `KonzertTicket` mit den Eigenschaften pro Ticket:
	- Ticketnummer
	- Bandname
	- Grundpreis
2. Denken Sie auch an die Attribute für den Preisfaktor und den Zähler, der mitzählt, wie viele Tickets insgesamt erstellt wurden.
3. Fügen Sie auch den Konstruktor hinzu, der Bandname und Grundpreis speichert (Parameterübergabe) und automatisch den Zähler erhöht und die Ticketnummer vergibt.
4. Zusätzlich soll es eine Methode `setPreisFaktor(double faktor)` geben.
5. Ergänzen Sie eine Methode `getEndpreis()`, die den endgültigen Ticketpreis berechnet
*(Formel: grundpreis * preisFaktor)*.
6. Überschreiben Sie die Methode `toString()`, um eine sinnvolle Ausgabe der Ticketdaten zu ermöglichen.
7. Schreiben Sie nun ein Java-Programm, das mehrere Tickets erzeugt und den Zähler sowie die berechneten Preise ausgibt.

## 2. Festivalbesucher

**Aufgabenstellung:** Ein Festival hat eine maximale Besucherzahl, die für alle Tage gilt. Jede Registrierung von Besucher:innen soll die Anzahl der verfügbaren Plätze reduzieren.

#### Schritte
1. Erstellen Sie eine Klasse `FestivalBesucher` mit den Eigenschaften pro Besucher:
	- Name
	- Wochentag (z.B. "Freitag")
2. Ergänzen Sie Attribute für die maximale Kapazität des Festivals und die aktuell registrierten Besucher (Anzahl).
3. Fügen Sie auch den Konstruktor hinzu, der prüft, ob noch Plätze frei sind und die Anzahl der registrierten Besucher erhöht.
4. Schreiben Sie einer Getter-Methode für den Wochentag.
5. Zusätzlich soll es eine Methode `setMaxKapazitaet(int kapazitaet)` geben.
6. Weiterhin soll es eine Methode `getFreiePlaetze()`geben, die zurückgibt, wie viele Plätze noch frei sind.
7. Schreiben Sie nun ein Java-Programm, das mehrere Besucher für Freitag, Samstag und Sonntag registriert. Zunächst sollen die noch freien Plätze ausgegeben werden. Danach soll für jeden Wochentag jeweils ausgegeben werden, wie viele Besucher registriert wurden.
class Messungen {

	static void gesamtAusgeben(double[][][] gebaeude) {
		for (int etage = 0; etage < gebaeude.length; etage++) {
			System.out.println("Etage: " + etage);
			for (int raum = 0; raum < gebaeude[etage].length; raum++) {
				System.out.println("\tRaum: " + raum);
				for (int i_messung = 0; i_messung < gebaeude[etage][raum].length; i_messung++) {
					System.out.printf("\t\tMessung: %.2f°C\n", gebaeude[etage][raum][i_messung]);
				}
			}
		}
	}

	static void hoechstTemperaturAusgeben(double[][][] gebaeude) {
		double max = 0.0;
		int maxEtage = -1;
		int maxRaum = -1;
		for (int etage = 0; etage < gebaeude.length; etage++) {
			for (int raum = 0; raum < gebaeude[etage].length; raum++) {
				for (int i_messung = 0; i_messung < gebaeude[etage][raum].length; i_messung++) {
					double aktMessung = gebaeude[etage][raum][i_messung];
					if (aktMessung > max) {
						max = aktMessung;
						maxEtage = etage;
						maxRaum = raum;
					}
				}
			}
		}
		System.out.println("Höchste Temperatur: " + max + " in Etage " + maxEtage + " in Raum " + maxRaum);
	}

	public static void main(String[] args) {
		double[][][] gebaeude = new double[3][4][7];

		for (int etage = 0; etage < gebaeude.length; etage++) {
			for (int raum = 0; raum < gebaeude[etage].length; raum++) {
				for (int i_messung = 0; i_messung < gebaeude[etage][raum].length; i_messung++) {
					double rand = 18.0 + Math.random() * 10.0;
					gebaeude[etage][raum][i_messung] = rand;
				}
			}
		}

		gesamtAusgeben(gebaeude);
		hoechstTemperaturAusgeben(gebaeude);
	}
}

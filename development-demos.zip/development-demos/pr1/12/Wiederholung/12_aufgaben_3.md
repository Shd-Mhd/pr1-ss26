# Wiederholung: Wunschthemen

## 1. Multi-dimensionale Arrays

Ein Gebäude hat 3 Etagen und 4 Räume pro Etage. In jedem Raum wird jeden Tag 7 mal die Temperatur gemessen.

**Aufgabenstellung:** Erzeugen Sie zufällige Werte zwischen 18.0°C und 28.0°C und belegen jeden Raum im Gebäude mit jeweils 7 Werten für einen Tag. Speichern Sie diese Daten in einem 3D-Array in Java. Finden Sie nun die höchste Temperatur im gesamten Gebäude und geben die zugehörige Etage und den Raum aus.

## 2. OOP mit Vererbung

In einem Spiel gibt es zwei verschiedene Spielfiguren: Magier und Kriegerinnen. Alle Spielfiguren besitzen Lebenspunkte und können sich bewegen. 

#### Anforderungen
- Bei der Erzeugung einer Spielfigur besitzt sie entweder standardmäßig 100 Lebenspunkte oder die Lebenspunkte können explizit gesetzt werden.
- Kriegerinnen besitzen bei der Erzeugung immer 150 Lebenspunkte, Magier besitzen 180 Lebenspunkte.
- Magier besitzen außerdem noch Magiepunkte, die explizit gesetzt werden müssen.
- Wenn eine Spielfigur sich bewegt, wird in der Konsole ausgegeben, wie viele Schritte gemacht wurden.
- Standardmäßig bewegt sich jede Spielfigur um 5 Schritte, ein Magier um 7 und eine Kriegerin um 10 Schritte.
- Magier können zaubern und verlieren dabei stets 5 Magiepunkte. Auch dieser Vorgang wird in der Konsole ausgegeben.

**Aufgabenstellung:** Schreiben Sie zunächst die Klassen `Spielfigur`, `Magier` und `Kriegerin`. Überschreiben Sie jeweils die von `Object` geerbte `toString()`-Methode. Schreiben Sie dann ein Java-Programm, welches jeweils eine Instanz eines Magiers und eine Instanz einer Kriegerin erzeugt und diese in einem Array von `Spielfigur` speichert. Iterieren Sie mit einer `foreach`-Schleife durch das Array und geben jede Spielfigur in der Konsole aus und bewegen Sie einmal. Danach lassen Sie den Magier einmal zaubern und geben ihn noch einmal in der Konsole aus.

## 3. Rekursion

**Aufgabenstellung:** Schreiben Sie eine rekursive Methode `static int digitSum(int n)`, die die Summe aller Ziffern einer positiven Zahl berechnet.

#### Beispiele
- `digitSum(1234)` &rarr; 10
- `digitSum(9)` &rarr; 9
- `digitSum(502)` &rarr; 7
- `digitSum(2395301)` &rarr; 23

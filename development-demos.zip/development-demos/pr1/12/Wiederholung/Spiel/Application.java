package Spiel;

public class Application {
	public static void main(String[] args) {
		Magier magier = new Magier(30);
		Kriegerin kriegerin = new Kriegerin();
		Spielfigur[] spielfiguren = new Spielfigur[2];
		spielfiguren[0] = magier;
		spielfiguren[1] = kriegerin;
		for (Spielfigur spielfigur : spielfiguren) {
			System.out.println(spielfigur);
			spielfigur.bewegen();
		}
		magier.zaubern();
		System.out.println(magier);
	}
}

package Spiel;

public class Kriegerin extends Spielfigur{

	Kriegerin(){
		super(150);
	}
	
	@Override
	void bewegen(){
		System.out.println("Die Kriegerin hat 10 Schritte gemacht.");
	}

		@Override
	public String toString(){
		return "Kriegerin [lebenspunkte= " + lebenspunkte + "]";
	}
}

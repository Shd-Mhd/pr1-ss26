package Spiel;

class Spielfigur {
	int lebenspunkte;

	Spielfigur(){
		this(100);
	}

	Spielfigur(int lebenspunkte){
		this.lebenspunkte = lebenspunkte;
	}

	void bewegen(){
		System.out.println("Die Spielfigur hat 5 Schritte gemacht.");
	}

}

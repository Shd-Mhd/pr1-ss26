package Spiel;

class Magier extends Spielfigur {
	int magiepunkte;

	Magier(int magiepunkte) {
		super(180);
		this.magiepunkte = magiepunkte;
	}

	@Override
	void bewegen() {
		System.out.println("Der Magier hat 7 Schritte gemacht.");
	}

	void zaubern() {
		if (magiepunkte >= 5) {
			magiepunkte -= 5;
			System.out.println("Der Magier hat gezaubert.");
		}else{
			System.out.println("Der Magier kann leider nicht mehr zaubern.");
		}
	}

	@Override
	public String toString(){
		return "Magier [lebenspunkte= " + lebenspunkte + ", magiepunkte=" + magiepunkte + "]";
	}
}
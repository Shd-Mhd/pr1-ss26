import java.util.Random;

public class GebaeudeTemperaturen {
    public static void main(String[] args) {

        double[][][] temperaturen = new double[3][4][7];
        Random random = new Random();

        double maxTemp = Double.MIN_VALUE;
        int maxEtage = 0;
        int maxRaum = 0;

        // Array mit Zufallswerten füllen
        for (int etage = 0; etage < temperaturen.length; etage++) {
            for (int raum = 0; raum < temperaturen[etage].length; raum++) {
                for (int messung = 0; messung < temperaturen[etage][raum].length; messung++) {

                    double temperatur = 18.0 + random.nextDouble() * 10.0;
                    temperaturen[etage][raum][messung] = temperatur;

                    if (temperatur > maxTemp) {
                        maxTemp = temperatur;
                        maxEtage = etage;
                        maxRaum = raum;
                    }
                }
            }
        }

        // Höchste Temperatur ausgeben
        System.out.printf("Höchste Temperatur: %.2f °C%n", maxTemp);
        System.out.println("Etage: " + (maxEtage + 1));
        System.out.println("Raum: " + (maxRaum + 1));
    }
}
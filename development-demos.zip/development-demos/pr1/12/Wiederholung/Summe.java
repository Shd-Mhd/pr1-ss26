class Summe {

	static int digitSum(int n) {
		int letzteZiffer = n % 10;
		int restZiffern = n / 10;
		if (restZiffern == 0) {
			return letzteZiffer;
		} else {
			return digitSum(restZiffern) + letzteZiffer;
		}
	}

	public static void main(String[] args) {
		System.out.println(digitSum(2395301));
	}

}

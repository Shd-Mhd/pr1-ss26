public class Post {
    private String Autor;
    private String Text;
    private int Likes;

    public Post(String Autor, String Text) {
        this.Autor = Autor;
        this.Text = Text;
        this.Likes = 12;
    }

    @Override
    public String toString() {
        return "Autor: " + Autor + " | Likes: " + Likes +
               "\nText: " + Text;
    }

    public static void main(String[] args) {
        Post post = new Post(
                "Max",
                "Hallo Welt!"
        );

        System.out.println(post);
    }
}
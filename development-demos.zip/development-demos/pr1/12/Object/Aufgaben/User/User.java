package User;

import java.util.Objects;

public class User {
	private String username;
	private String email;

	public User(String username, String email) {
		this.username = username;
		this.email = email;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof User))
			return false;
		User other = (User) obj;
		return Objects.equals(username, other.username) &&
				Objects.equals(email, other.email);
	}

	@Override
	public int hashCode() {
		return Objects.hash(username, email);
	}
}

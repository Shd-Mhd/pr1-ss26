package User;

public class Application {
	public static void main(String[] args) {
		User user1 = new User("Donald", "donald@ducktales.com");
		User user2 = new User("Donald", "donald@ducktales.com");
		if (user1.equals(user2)){
			System.out.println("Gleich");
		}else{
			System.out.println("Ungleich");
		}
	}
}

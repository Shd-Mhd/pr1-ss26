package Profil;

public class Application {
	public static void main(String[] args) {
		Profil p1 = new Profil("Amar", "Love coding!");
		Profil p2 = p1.clone();

		p2.setKurzprofil("I love Java!");

		System.out.println("Profil 1: " + p1.getName() + " -> " + p1.getKurzprofil());
		System.out.println("Profil 2: " + p2.getName() + " -> " + p2.getKurzprofil());
	}
}

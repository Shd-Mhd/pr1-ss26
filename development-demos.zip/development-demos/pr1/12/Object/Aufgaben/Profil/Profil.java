package Profil;

public class Profil implements Cloneable {
	private String name;
	private String kurzprofil;

	public Profil(String name, String kurzprofil) {
		this.name = name;
		this.kurzprofil = kurzprofil;
	}

	public String getName() {
		return name;
	}

	public void setKurzprofil(String bio) {
		this.kurzprofil = bio;
	}

	public String getKurzprofil() {
		return kurzprofil;
	}

	@Override
	public Profil clone() {
		try {
			return (Profil) super.clone();
		} catch (CloneNotSupportedException e) {
			return null;
		}
	}
}

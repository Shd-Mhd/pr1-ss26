# Object

## 1. Social‑Media‑Post

**Aufgabenstellung:** Erstellen Sie eine Klasse `Post`, die einen einfachen Social‑Media‑Beitrag beschreibt.

#### Schritte
1. Die Klasse besitzt folgende Eigenschaften:
 - Autor
 - Text
 - Likes (Anzahl)
2. Erstellen Sie einen Post und geben Sie ihn mit `System.out.println(post)` aus. Beobachten Sie, wie Java das Objekt standardmäßig darstellt.
3. Überschreiben Sie `toString()`, sodass die Ausgabe folgendermaßen aussieht:
```
Autor: Max | Likes: 12
Text: Hallo Welt!
```
4. Geben Sie denselben Post erneut aus und vergleichen Sie beide Ausgaben.

## 2. Social‑Media‑User
**Aufgabenstellung:** Erstellen Sie eine Klasse `User`, die einen einfachen Social-Media-Account modelliert.

#### Schritte
1. Die Klasse hat folgende Eigenschaften:
	- Username
	- Email
2. Erstellen Sie zwei User‑Objekte `user1` und `user2` mit identischen Daten. Vergleichen Sie sie mit `user1.equals(user2)`. Was beobachten Sie?
3. Überschreiben Sie `equals()` so, dass zwei User gleich sind, wenn Username und Email übereinstimmen.
4. Überschreiben Sie `hashCode()` passend dazu.
5. Testen Sie erneut `user1.equals(user2)` und vergleichen Sie das Verhalten.

## 3. Social‑Media‑Profil
**Aufgabenstellung:** Erstellen Sie eine Klasse `Profil`, welches ein einfaches Social-Media-Profil verwaltet.

#### Schritte
1. Die Klasse hat folgende Eigenschaften:
	- Name
	- Kurzprofil
2. Erstellen Sie zwei Profil‑Objekte und weisen Sie eines dem anderen zu:
```java
Profil p2 = p1;
```
3. Ändern Sie das Kurzprofil von p2. Geben Sie das Kurzprofil von p1 und p2 aus. Was beobachten Sie?
4. Überschreiben Sie `clone()`, sodass eine *flache Kopie* entsteht.
5. Erstellen Sie nun:
```java
Profil p2 = p1.clone();
```
6. Ändern Sie das Kurzprofil von p2. Überprüfen Sie, ob p1 unverändert geblieben ist und beide Objekte unabhängig voneinander existieren.
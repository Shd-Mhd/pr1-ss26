import java.util.Objects;

public class User {
    private String username;
    private String email;

    public User(String username, String email) {
        this.username = username;
        this.email = email;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        User other = (User) obj;

        return username.equals(other.username)
                && email.equals(other.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(username, email);
    }
    
    public class Main {
    public static void main(String[] args) {
        User user1 = new User("max", "max@example.com");
        User user2 = new User("max", "max@example.com");

        System.out.println(user1.equals(user2));
        }
    }
}


package Post;

public class Application {
	public static void main(String[] args) {
		Post meinPost = new Post("Maxime", "Der Sommer ist da!");
		meinPost.increaseLikes();
		System.out.println(meinPost);
	}
}

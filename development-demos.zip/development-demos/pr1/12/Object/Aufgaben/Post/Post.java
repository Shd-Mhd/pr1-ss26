package Post;

public class Post {
	private String autor;
	private String text;
	private int likes;

	public Post(String autor, String text){
		this.autor = autor;
		this.text = text;
		this.likes = 0;
	}

	public void increaseLikes(){
		likes++;
	}

	@Override
	public String toString(){
		return "Autor: " + autor + " | Likes: " + likes + "\nText: " + text;
	}
}

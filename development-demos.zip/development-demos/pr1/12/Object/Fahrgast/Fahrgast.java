package Fahrgast;

public class Fahrgast implements Cloneable {

    private String name;
    private String ticketInfo;

    public Fahrgast(String name, String ticketInfo) {
        this.name = name;
        this.ticketInfo = ticketInfo;
    }

    public void setTicketInfo(String ticketInfo) {
        this.ticketInfo = ticketInfo;
    }

	public String getName() {
        return name;
    }

    public String getTicketInfo() {
        return ticketInfo;
    }

    @Override
    public Fahrgast clone() {
        try {
            return (Fahrgast) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}
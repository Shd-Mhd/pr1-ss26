package Fahrgast;

public class Application {
	public static void main(String[] args) {

		Fahrgast f1 = new Fahrgast("Lena", "Monatskarte – Zone 3");
		Fahrgast f2 = f1.clone();

		f2.setTicketInfo("Einzelticket – Kurzstrecke");

		System.out.println("Fahrgast 1: " + f1.getName() + " " + f1.getTicketInfo());
		System.out.println("Fahrgast 2: " + f2.getName() + " " + f2.getTicketInfo());
	}
}
package Fahrrad;

import java.util.Objects;

public class Fahrrad {

	private String rahmennummer;
	private String modell;

	public Fahrrad(String rahmennummer, String modell) {
		this.rahmennummer = rahmennummer;
		this.modell = modell;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true; // gleiche Referenz
		if (!(obj instanceof Fahrrad))
			return false; // falscher Typ
		Fahrrad other = (Fahrrad) obj;

		return Objects.equals(rahmennummer, other.rahmennummer) &&
				Objects.equals(modell, other.modell);
	}

	@Override
	public int hashCode() {
		return Objects.hash(rahmennummer, modell);
	}
}

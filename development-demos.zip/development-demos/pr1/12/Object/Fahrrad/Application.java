package Fahrrad;

public class Application {
	public static void main(String[] args) {

		Fahrrad f1 = new Fahrrad("R123456789", "Mountainbike");
		Fahrrad f2 = new Fahrrad("R123456789", "Mountainbike");

		if (f1.equals(f2)) {
			System.out.println("Gleich");
		} else {
			System.out.println("Ungleich");
		}
	}
}
package mypack;

public class MyPackageMain {
	public static void main(String[] args) {
		System.out.println("This is my package!");
		Hello.hello();
	}	
}

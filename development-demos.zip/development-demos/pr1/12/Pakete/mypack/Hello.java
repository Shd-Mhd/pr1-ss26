package mypack;

public class Hello {
	public static void hello(){
		System.out.println("Hello");
	}
}

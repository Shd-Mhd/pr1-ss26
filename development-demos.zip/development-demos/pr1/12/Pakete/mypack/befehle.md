#### Kompilieren und Ausführen
0. Terminal starten
1. In Ordner `mypack` wechseln und
	1. ` javac -d . *.java`
	2. `java mypack.MyPackageMain`
# Aktivitätsdiagramme

## Sequenz

**Beschreibung**

Die Aktivität beginnt damit, dass **Elena** ihre **Laufkleidung anzieht**. Anschließend streift Elena ihre **Laufschuhe über**, um vollständig vorbereitet zu sein. Danach geht sie **zum Startpunkt**. Dort angekommen, läuft Elena **eine Bahn**. Nach dem Lauf nimmt sie sich einen Moment Zeit, **Wasser zu trinken**, um sich zu erfrischen. Zum Abschluss geht Elena **duschen** und  und **zieht sich um**, womit der Ablauf endet.

## Entscheidungsknoten

**Beschreibung**

Bevor Kareem das Haus verlässt, prüft er das Wetter: Wenn es regnet, nimmt er einen Regenschirm mit. Wenn es nicht regnet und die Sonne scheint, setzt er eine Sonnenbrille auf. Erst danach geht er aus dem Haus.

## Schleifen

**Beschreibung**

Der Ablauf beginnt damit, dass das Team die Anforderungen definiert. Anschließend werden auf Basis dieser Anforderungen die Tests erstellt. Danach folgt eine wiederholte Arbeitsphase: Solange die Tests nicht bestanden sind, wird zunächst ein Konzept erstellt und anschließend programmiert. Danach werden die Tests erneut ausgeführt, um das Ergebnis zu überprüfen. Sobald alle Tests erfolgreich bestanden wurden, wird das Programm ausgeliefert, womit der Ablauf endet.

## Zählschleife

**Beschreibung**

Die Aktivität beginnt damit, dass Mariam ihre Laufkleidung anzieht. Anschließend streift sie ihre Laufschuhe über, um vollständig vorbereitet zu sein. Danach geht sie zum Startpunkt. Dort angekommen, läuft Mariam 5 Bahnen. Nach dem Lauf nimmt sie sich einen Moment Zeit, Wasser zu trinken, um sich zu erfrischen. Zum Abschluss geht Mariam duschen und  und zieht sich um, womit der Ablauf endet.

# Pseudocode

## Algorithmus

**Aufgabenstellung:** 

Formuliere einen Algorithmus, der den Ablauf zur Planung und Buchung eines Wochenendtrips beschreibt. Der Algorithmus soll:
- ein verfügbares Budget berücksichtigen  
  - ein geeignetes Reiseziel auswählen: 
  	- geringes Budget &rarr; nahes Ziel
	- großes Budget &rarr; fernes Ziel
  - eine geeignete Unterkunft buchen : 
  	- geringes Budget &rarr; Jugendherberge
	- großes Budget &rarr; Hotel
- eine passende Transportart buchen:
	- nahes Ziel &rarr; Bahn
	- fernes Ziel &rarr; Flugzeug
- am Ende eine kurze Bestätigung ausgeben  

Nutze **deutsche Schlüsselwörter** wie `WENN`, `SONST`, `SOLANGE`, `DEKLARIERE`, `BUCHEN`, `AUSGABE`.  

public class Fakultaet {

	static long fakRek(int n) {
		return (n > 1) ? n * fakRek(n - 1) : 1;
	}

	static long fakIter(int n) {
		long ergebnis = 1;
		for (int i = 2; i <= n; i++) {
			ergebnis = ergebnis * i;
		}
		return ergebnis;
	}

	public static void main(String[] args) {
		int n = 0;
		System.out.println("Fakultät von " + n + " (rekursiv): " + fakRek(n));
		System.out.println("Fakultät von " + n + " (iterativ): " + fakIter(n));
	}
}

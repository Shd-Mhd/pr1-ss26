# Rekursion

## 1. Zinsrechnung

**Aufgabenstellung:** Ein Kapital von 1000 Euro wird jährlich mit 5% verzinst. Die rekursive Methode `kapital(n)` soll den Kapitalwert nach n Jahren ausgeben. Schreiben Sie ein Java-Programm, das diese Methode implementiert und mehrmals mit unterschiedlichen Parametern aufruft.

#### Schritte
1. Die folgenden Problemreduktionsschritte sollen dem Algorithmus zu Grunde liegen.
```
kapital(0) -> 1000

kapital(5) -> kapital(4) + 0.05 * kapital(4)
```
2. Verallgemeinere diese Reduktionsschritte zu einer rekursiven Funktionsdefinition.
3. Rufen Sie Ihre Methode auf und geben das Ergebnis in der Konsole aus.
4. Wiederholen Sie Schritt 3 mit unterschiedlichen Aktualparametern.

*Quelle:* inf-schule: "Übungen zur Rekursion". Online verfügbar unter: https://inf-schule.de/imperative-programmierung/python/konzepte/rekursion/uebungen (Zugriff: 15.05.2026).

## 2. Medikamentenmenge

**Aufgabenstellung:** Ein Patient nimmt jeden Morgen 5 mg eines Medikaments ein. Im Laufe des Tages werden von dem gesamten, im Körper befindlichen Medikament 40% abgebaut. Die rekursive Methode `medikamentenmenge(n)` beschreibe die Menge des Medikaments (in mg), die sich am n-ten Tag **morgens** nach Einnahme des Medikaments im Körper befindet. Schreiben Sie ein Java-Programm, das diese Methode implementiert und mehrmals mit unterschiedlichen Parametern aufruft.

#### Schritte
1. Ergänzen Sie die folgenden Problemreduktionsschritte und verallgemeineren Sie sie zu einer rekursiven Funktionsdefinition.

```
medikamentenmenge(0) ->  ...

medikamentenmenge(5) ->  ...
```
2. Rufen Sie Ihre Methode auf und geben das Ergebnis in der Konsole aus.
3. Wiederholen Sie Schritt 3 mit unterschiedlichen Aktualparametern.

*Quelle:* inf-schule: "Übungen zur Rekursion". Online verfügbar unter: https://inf-schule.de/imperative-programmierung/python/konzepte/rekursion/uebungen (Zugriff: 15.05.2026).

## 3. Collatz-Folge (rekursiv)

**Aufgabenstellung:** Die **Collatz-Folge** (Lothar Collatz, 1937) ist eine Zahlenfolge, die ausgehend von einer positiven ganzen Zahl $n$ nach folgenden Regeln gebildet wird:

- Wenn $n$ **gerade** ist, dann gilt:
  $$
  n_{k+1} = \frac{n_k}{2}
  $$
- Wenn $n$ **ungerade** ist, dann gilt:
  $$
  n_{k+1} = 3n_k + 1
  $$

Diese Schritte werden wiederholt, solange $n > 1$ gilt.  
Die Collatz‑Vermutung behauptet, dass jede Folge auf 4, 2, 1 endet, aber warum das so ist, ist bis heute ungeklärt und ein ungelöstes Problem der Mathematik.

Schreiben Sie ein Java-Programm mit einer **rekursiven** Methode, die den größten erreichten Zwischenwert einer Collatz-Folge berechnet.

*Quelle:* "Captain CiaoCiao erobert Java – Das Trainingsbuch für besseres Java" von Christian Ullenboom.
package Aufgaben;

public class Kapital {

	public static double kapital(int anzJahre) {
		final int START_KAPITAL = 1000;
		final double ZINSSATZ = 0.05;

		if (anzJahre == 0) {
			return START_KAPITAL;
		} else {
			return kapital(anzJahre - 1) + (kapital(anzJahre - 1) * ZINSSATZ);
		}
	}

	public static void main(String[] args) {
		int n = 5;
		System.out.printf("Kapital nach %d Jahren: %.2f€\n", n, kapital(n));
	}
}

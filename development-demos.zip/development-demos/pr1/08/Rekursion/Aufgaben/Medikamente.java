package Aufgaben;

public class Medikamente {

	static double medikamentenmenge(int anzTage) {
		final int DOSIS_IN_MG = 5;
		final double ABBAU_RATE = 0.4;
		if (anzTage == 0) {
			return 0;
		} else if (anzTage == 1) {
			return DOSIS_IN_MG;
		} else {
			return DOSIS_IN_MG + (medikamentenmenge(anzTage - 1) * (1-ABBAU_RATE));
		}
	}

	public static void main(String[] args) {
		int n = 3;
		System.out.printf("Am Morgen des %d.ten Tag befinden sich %.4fmg des Medikaments im Körper.", n, medikamentenmenge(n));
	}
}

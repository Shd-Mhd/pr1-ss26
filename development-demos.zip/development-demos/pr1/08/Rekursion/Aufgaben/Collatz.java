public class Collatz {
	static void collatz(long n) {
		System.out.print(n);
		while (n != 1) {
			if (n % 2 == 0) {
				n = n / 2;
			} else {
				n = (3 * n) + 1;
			}
			System.out.print("->");
			System.out.print(n);
		}
	}

	static long collatzMax(long n) {
		long max = n;
		while (n != 1) {
			if (n % 2 == 0) {
				n = n / 2;
				max = n > max ? n : max;
			} else {
				n = (3 * n) + 1;
				max = n > max ? n : max;
			}
		}
		return max;
	}

	static long collatzRek(long n, long max) {
		if (n == 1)
			return max;
		if (n % 2 == 0) {
			long c = n / 2;
			long max_temp = max > c ? max : c;
			return collatzRek(c, max_temp);
		} else {
			long c = 3 * n + 1;
			long max_temp = max > c ? max : c;
			return collatzRek(c, max_temp);
		}
	}

	public static void main(String[] args) {
		long next = 27;
		collatz(next);
		System.out.println();
		System.out.println("Max: " + collatzMax(next));
		System.out.println("Max: " + collatzRek(next, next));
	}
}

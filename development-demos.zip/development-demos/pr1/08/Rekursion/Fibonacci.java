public class Fibonacci {

	static long fibRek(int n) {
		if (n == 0)
			return 0;
		return (n > 2) ? fibRek(n - 1) + fibRek(n - 2) : 1;
	}

	static long fibIter(int n) {
		long n2 = 1;
		long n1 = 1;
		long n0 = 0;

		for (int i = 3; i <= n; i++) {
			n0 = n1 + n2;
			n2 = n1;
			n1 = n0;
		}

		return n0;
	}

	public static void main(String[] args) {
		int n = 6;
		System.out.println("Fibonacci-Zahl von " + n + " (rekursiv): " + fibRek(n));
		System.out.println("Fibonacci-Zahl von " + n + " (iterativ): " + fibIter(n));
	}
}

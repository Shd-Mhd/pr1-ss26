public class MethodenStack {
	public static void methodA() {
		for (int varA1 = 0; varA1 < 3; varA1++) {
			System.out.println("methodA()  --> varA1  = " + varA1);
			methodB(varA1);
		}
	}

	public static void methodB(int varB1) {
		int varB2 = 1;
		System.out.println("+--methodB()   --> varB1  = " + varB1 + " varB2  = " + varB2);
		methodC(varB1, varB2);
	}

	public static void methodC(int varC1, int varC2) {
		System.out.println("+----methodC() --> varC1 = " + varC1 + " varC2 = " + varC2);
		System.out.println();
	}

	public static void main(String[] args) {
		methodA();
	}
}
# Methoden (2)

## 1. Buchladen
**Aufgabenstellung:** Ein Buchladen verwaltet seine Bücher in einem Lager und muss am Ende eines Verkaufstages seinen Rohertrag berechnen. Bücher besitzen die Eigenschaften Titel, Einkaufspreis und Verkaufspreis. Das Lager des Buchladens enthält jedes Buch mit der dazugehörigen Anzahl davon im Lager (=Titelbestand). Bei jedem verkauften Buch errechnet sich der Rohertrag folgendermaßen:

$$
\text{Umsatzsteuer} = \text{Verkaufspreis} \cdot 0.07
$$
$$
\text{Rohertrag} = \text{Verkaufspreis} - \text{Umsatzsteuer} - \text{Einkaufspreis}
$$

Schreiben Sie zwei Methoden in Java, die zum Einen den Verkauf eines Buches und zum Anderen die Berechnung des Rohertrags durchführen. Verwenden Sie diese Methoden, um einen Verkaufstag des Buchladens zu simulieren.

#### Schritte
1. Erstellen Sie die Klassen zu Buch und Titelbestand.
2. Erstellen sie mind. drei Buch-Objekte und füge jedes als Titelbestand-Objekt (Buch und Anzahl) zum Lager hinzu.
3. Simulieren Sie den Verkauf von mind. vier Büchern:
	1. Reduzieren Sie die Anzahl des entsprechenden Titelbestands im Lager.
	2. Berechnen Sie den Rohertrag für den Verkauf.
4. Geben Sie den Rohertrag am Ende des Verkaufstags aus.
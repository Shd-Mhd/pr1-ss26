package Fragezeichen;

public class Fragezeichen {
	String vorname;
	String nachname;
	String geburtstag;
}

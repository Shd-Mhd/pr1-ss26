package Buchladen;

public class Buchladen {

	static double verkaufen(Titelbestand[] bestand, String titel) {
		for (int i = 0; i < bestand.length; i++) {
			if (bestand[i].buch.titel.equals(titel)) {
				if (bestand[i].anzahl > 0) {
					System.out.printf("Buch verkauft: %s\n", titel);
					bestand[i].anzahl--;
					System.out.printf("\tNeuer Bestand: %d\n", bestand[i].anzahl);
					return rohertragBerechnen(bestand[i].buch.verkaufspreis, bestand[i].buch.einkaufspreis);
				} else {
					System.out.println("Das Buch ist ausverkauft.");
					return 0;
				}
			}
		}
		return 0;
	}

	static double rohertragBerechnen(double verkaufspreis, double einkaufspreis) {
		final double UMSATZSTEUERSATZ = 0.07;
		double umsatzsteuer = verkaufspreis * UMSATZSTEUERSATZ;
		double rohertrag = verkaufspreis - umsatzsteuer - einkaufspreis;
		return rohertrag;
	}

	public static void main(String[] args) {
		// Liste mit Büchern
		Buch gdw = new Buch();
		gdw.titel = "Der Gott des Waldes";
		gdw.verkaufspreis = 24.99;
		gdw.einkaufspreis = 15.50;
		Titelbestand b1 = new Titelbestand();
		b1.buch = gdw;
		b1.anzahl = 10;

		Buch hi = new Buch();
		hi.titel = "Halbinsel";
		hi.verkaufspreis = 12.99;
		hi.einkaufspreis = 8.50;
		Titelbestand b2 = new Titelbestand();
		b2.buch = hi;
		b2.anzahl = 5;

		Buch wk = new Buch();
		wk.titel = "Wackelkontakt";
		wk.verkaufspreis = 17.99;
		wk.einkaufspreis = 12.50;
		Titelbestand b3 = new Titelbestand();
		b3.buch = wk;
		b3.anzahl = 5;

		Titelbestand[] lager = { b1, b2, b3 };
		double aktuellerRohertrag = 0;

		aktuellerRohertrag += verkaufen(lager, "Der Gott des Waldes");
		aktuellerRohertrag += verkaufen(lager, "Wackelkontakt");
		aktuellerRohertrag += verkaufen(lager, "Der Gott des Waldes");
		aktuellerRohertrag += verkaufen(lager, "Halbinsel");

		System.out.println("Der heutige Rohertrag: " + (int) (aktuellerRohertrag * 100) / 100.0 + "€");
	}
}

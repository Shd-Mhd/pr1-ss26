package Buchladen;
public class Buch {
	String titel;
	double verkaufspreis;
	double einkaufspreis;
}
package Buchladen;
public class Titelbestand {
	Buch buch;
	int anzahl;
}

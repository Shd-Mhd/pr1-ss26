
public class Umsatz {
	public static void main(String[] args) {
		int[] gewinne = new int[31];
		for (int i = 0; i < gewinne.length; i++) {
			gewinne[i] = 10 + (int) (Math.random() * 1000) * 10; // Gewinne liegen zwischen 10 und 10000 in
																	// 10er-Schritten
		}
		for (int i = 0; i < gewinne.length - 1; i++) {
			double differenz = gewinne[i + 1] - gewinne[i];
			double prozentsteigerung = differenz / gewinne[i] * 100;
			if (prozentsteigerung > 5.0) {
				System.out.println(
						"Tag " + i + ": " + gewinne[i] + "->" + gewinne[i + 1] + ": "
								+ (int) (prozentsteigerung * 100) / 100.0 + "%");
			}
		}
	}
}

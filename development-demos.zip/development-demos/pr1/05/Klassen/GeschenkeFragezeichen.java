import java.util.Scanner;

class Fragezeichen {
	String vorname;
	String nachname;
	String geburtstag;
}

public class GeschenkeFragezeichen {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		Fragezeichen detektiv1 = new Fragezeichen();
		detektiv1.vorname = "Justus";
		detektiv1.nachname = "Jonas";
		detektiv1.geburtstag = "1.4.1950";

		Fragezeichen detektiv2 = new Fragezeichen();
		detektiv2.vorname = "Bob";
		detektiv2.nachname = "Andrews";
		detektiv2.geburtstag = "11.9.1950";

		Fragezeichen detektiv3 = new Fragezeichen();
		detektiv3.vorname = "Peter";
		detektiv3.nachname = "Shaw";
		detektiv3.geburtstag = "17.6.1950";

		for (int i = 1; i <= 3; i++) {
			Fragezeichen aktuellerDetektiv;
			switch (i) {
				case 1:
					aktuellerDetektiv = detektiv1;
					break;
				case 2:
					aktuellerDetektiv = detektiv2;
					break;
				case 3:
					aktuellerDetektiv = detektiv3;
					break;
				default:
					aktuellerDetektiv = new Fragezeichen();
					break;
			}
			System.out.print("Ist heute der " + aktuellerDetektiv.geburtstag + "? ");
			boolean hatGeburtstag = scanner.nextBoolean();
			if (hatGeburtstag) {
				System.out.println(
						"Happy Birthday, " + aktuellerDetektiv.vorname + " " + aktuellerDetektiv.nachname + "!");
			}
		}

		scanner.close();
	}
}

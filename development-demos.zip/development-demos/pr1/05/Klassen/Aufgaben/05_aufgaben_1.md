# Klassen

## 1. UML-Klassendiagramme

**Aufgabenstellung:** Erstellen Sie UML-Klassendiagramme zu folgenden Klassen:

1. Rechteck
2. Buch
3. Spielfigur
4. Bankkonto
5. Person (mit Adresse)
import java.util.Scanner;

public class Geschenke {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		Fragezeichen detektiv1 = new Fragezeichen();
		detektiv1.vorname = "Bob";
		detektiv1.nachname = "Andrews";
		detektiv1.geburtstag = "11.9.1950";



		System.out.print("Ist heute der " + geburtstag + "? ");
		boolean hatGeburtstag = scanner.nextBoolean();
		if (hatGeburtstag) {
			System.out.println("Happy Birthday, " + vorname + " " + nachname + "!");
		}

		scanner.close();
	}
}

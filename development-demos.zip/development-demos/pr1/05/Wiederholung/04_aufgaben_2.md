# Schleifen

## 1. For-Schleife: Perlenkette

**Aufgabenstellung:** Erzeugen Sie ein SVG-Dokument, dass eine bunte Perlenkette zeichnet. Die Perlen sollen als Kreise in den Farben `blue`, `green` oder `orange` dargestellt und nebeneinander gereiht werden. Dabei soll die Kette 50 Perlen mit zufälliger Farbwahl enthalten.

#### SVG-Beispiel mit 5 Perlen
```svg
<svg height='100' width='1000'>
 <circle cx='20' cy='20' r='5.0' fill='orange' />
 <circle cx='30' cy='20' r='5.0' fill='blue' />
 <circle cx='40' cy='20' r='5.0' fill='blue' />
 <circle cx='50' cy='20' r='5.0' fill='blue' />
 <circle cx='60' cy='20' r='5.0' fill='green' />
</svg>
```

*Hinweis:* https://www.w3schools.com/graphics/svg_intro.asp

## 2. For-Schleife: Fischmuster
**Aufgabenstellung:** Mit den Symbolen `<` und `>` lassen sich die Stick-Motive `<><` und `><>` erstellen. Schreiben Sie in ein Java-Programm, dass gemäß der Belegung einer einer Variablen `wiederholungen` ein bestimmtes Stick-Muster aus diesen Motiven erstellt.

#### Beispiele
1. `wiederholungen=2`
```
><> ><> <>< <>< 
><> ><> <>< <><
```

2. `wiederholungen=5`
```
><> ><> ><> ><> ><> <>< <>< <>< <>< <>< 
><> ><> ><> ><> ><> <>< <>< <>< <>< <>< 
><> ><> ><> ><> ><> <>< <>< <>< <>< <>< 
><> ><> ><> ><> ><> <>< <>< <>< <>< <>< 
><> ><> ><> ><> ><> <>< <>< <>< <>< <><
```

*Quelle:* "Captain CiaoCiao erobert Java – Das Trainingsbuch für besseres Java" von Christian Ullenboom.

## 3. Do-While-Schleife: Summe

**Aufgabenstellung:** Schreiben Sie ein Java-Programm, dass ganze Zahlen über die Kommandozeile einliest. Bei Eingabe der 0 werden die bisher eingegebenen Zahlen addiert und das Ergebnis ausgegeben.

## 4. For-Schleife: Denksport

**Aufgabenstellung:** Schreiben Sie ein Java-Programm, das folgendes Rätsel durch Ausprobieren aller Möglichkeiten löst, alle Lösungen ausgibt und solche markiert, in denen X, O, L und T unterschiedlich sind.

#### Rätsel
|   |100er|10er|1er|
|---|---|---|---|
|   | X | O | L |
| + | L | X | X |
| = | T | L | T |

Für die Buchstaben L, O, T und X muss jeweils eine Ziffer (0-9) gefunden werden, sodass die Rechnungen stimmen.

*Quelle:* "Captain CiaoCiao erobert Java – Das Trainingsbuch für besseres Java" von Christian Ullenboom.
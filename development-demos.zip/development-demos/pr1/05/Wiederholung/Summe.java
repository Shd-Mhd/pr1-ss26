import java.util.Scanner;

public class Summe {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int summe = 0;
		int eingabe;
		do {
			eingabe = scanner.nextInt();
			summe += eingabe;
		} while (eingabe != 0);

		System.out.println("Summe: " + summe);
		scanner.close();
	}
}

public class Denksport {
	public static void main(String[] args) {
		for (int x = 0; x < 10; x++) {
			for (int l = 0; l < 10; l++) {
				for (int o = 0; o < 10; o++) {
					for (int t = 0; t < 10; t++) {
						int xol = 100 * x + 10 * o + l;
						int lxx = 100 * l + 10 * x + x;
						int tlt = 100 * t + 10 * l + t;
						if (xol + lxx == tlt) {
							System.out.print("Lösung:");
							System.out.print(" L: " + l);
							System.out.print(" O: " + o);
							System.out.print(" T: " + t);
							System.out.print(" X: " + x);
							if ((l != o) && (l != t) && (l != x) && (o != t) && (o != x) && (t != x)) {
								System.out.println(" ***");
							} else {
								System.out.println();
							}
						}
					}
				}
			}
		}
	}
}

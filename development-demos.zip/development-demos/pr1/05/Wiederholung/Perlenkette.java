public class Perlenkette {
	public static void main(String[] args) {
		int x = 20;
		int y = 20;
		double radius = 5;

		System.out.println(
				"<svg height='100' width='1000'>");
		for (int i = 0; i < 50; i++) {
			double colourRand = Math.random();
			String colour;
			if (colourRand < 1.0 / 3) {
				colour = "blue";
			} else if (colourRand < 2.0 / 3) {
				colour = "green";
			} else {
				colour = "orange";
			}
			System.out.println(
					" <circle cx='" + (x + i * 10) + "' cy='" + y + "' r='" + radius + "' fill='" + colour + "' />");
		}

		System.out.println(
				"</svg>");
	}
}

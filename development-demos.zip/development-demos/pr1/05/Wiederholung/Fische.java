public class Fische {
	public static void main(String[] args) {
		int wiederholungen = 10;

		for (int zeile = 0; zeile < wiederholungen; zeile++) {
			for (int rechts = 0; rechts < wiederholungen; rechts++) {
				System.out.print("><> ");
			}
			for (int links = 0; links < wiederholungen; links++) {
				System.out.print("<>< ");
			}
			System.out.println();
		}
	}
}

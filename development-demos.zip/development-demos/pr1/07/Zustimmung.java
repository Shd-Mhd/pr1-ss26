public class Zustimmung {
	static boolean allTrue(boolean... antworten) {
		if (antworten == null || antworten.length == 0) {
			return false;
		}
		for (boolean antwort : antworten) {
			if (antwort == false) {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {
		System.out.println(allTrue(true, true, true));
		System.out.println(allTrue(true, true, false, true));
		System.out.println(allTrue(null));
		System.out.println(allTrue());
	}
}

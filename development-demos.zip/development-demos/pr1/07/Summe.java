import java.util.Scanner;

public class Summe {
	static void printSum(int a, int b) {
		int sum = a + b;
		System.out.println(sum);
	}

	static int addiere(int a, int b) {
		int sum = a + b;
		return sum;
	}

	public static void main(String[] args) {
		printSum(2, 55);

		Scanner scanner = new Scanner(System.in);
		int summand1 = scanner.nextInt();
		int summand2 = scanner.nextInt();
		printSum(summand1, summand2);

		int summe = addiere(summand1, summand2);
		System.out.println(summe);

		scanner.close();
	}
}

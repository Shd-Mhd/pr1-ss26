public class Collatz {
	static void collatz(long n) {
		System.out.print(n);
		while (n != 1) {
			if (n % 2 == 0) {
				n = n / 2;
			} else {
				n = (3 * n) + 1;
			}
			System.out.print("->");
			System.out.print(n);
		}
	}

	static long collatzMax(long n) {
		long max = n;
		while (n != 1) {
			if (n % 2 == 0) {
				n = n / 2;
				max = n > max ? n : max;
			} else {
				n = (3 * n) + 1;
				max = n > max ? n : max;
			}
		}
		return max;
	}

	public static void main(String[] args) {
		long next = 10;
		collatz(next);
		System.out.println();
		System.out.println("Max: " + collatzMax(next));
	}
}

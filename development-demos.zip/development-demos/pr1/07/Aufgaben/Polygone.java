public class Polygone {

	static void erstelleSVGPolygon(int... koordinaten) {
		if (koordinaten == null || koordinaten.length == 0 || koordinaten.length % 2 != 0) {
			System.out.println("Es konnte kein SVG erstellt werden.");
		}

		System.out.println("<svg height='200' width='500'>");
		System.out.print(" <polygon points='");
		for (int i = 0; i < koordinaten.length; i = i + 2) {
			System.out.print(koordinaten[i] + "," + koordinaten[i + 1] + " ");
		}
		System.out.println("' />");
		System.out.println("</svg>");
	}

	public static void main(String[] args) {
		erstelleSVGPolygon(123, 200, 384, 556, 33, 54);
	}
}

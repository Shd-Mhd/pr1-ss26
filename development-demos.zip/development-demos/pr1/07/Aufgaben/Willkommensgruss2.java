public class Willkommensgruss2 {
	static void funkeln() {
		final String STERNE = "\u2728";
		funkeln(10, STERNE);
	}

	static void funkeln(int len) {
		final String STERNE = "\u2728";
		funkeln(len, STERNE);
	}

	static void funkeln(int len, String zeichen) {
		for (int i = 0; i < len; i++) {
			System.out.print(zeichen);
		}
	}

	static void funkeln(String prefix, int len, String zeichen, String suffix) {
		System.out.print(prefix);
		funkeln(len, zeichen);
		System.out.print(suffix);
	}

	static void willkommen() {
		final String GRUß = "Herzlich Willkommen!";
		System.out.print(GRUß);
	}

	public static void main(String[] args) {
		funkeln();
		System.out.println();
		willkommen();
		System.err.println();
		funkeln();
		System.out.println();
		funkeln(15);
		System.out.println();
		willkommen();
		System.out.println();
		funkeln(15);
		System.out.println();
		funkeln("--", 20, "\u2747", "--");
		System.out.println();
		willkommen();
		System.out.println();
		funkeln("++", 20, "\u2747", "++");
	}
}

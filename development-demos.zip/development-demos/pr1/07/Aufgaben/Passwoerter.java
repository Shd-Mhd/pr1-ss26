public class Passwoerter {
	static final int MIN_PASSWORD_LEN = 8;

	static boolean istLangGenug(String passwort) {
		return passwort.length() >= MIN_PASSWORD_LEN;
	}

	static boolean enthaeltGrossbuchstaben(String passwort) {
		for (int i = 0; i < passwort.length(); i++) {
			char c = passwort.charAt(i);
			if (Character.isUpperCase(c)) {
				return true;
			}
		}
		return false;
	}

	static boolean enthaeltKleinbuchstaben(String passwort) {
		for (int i = 0; i < passwort.length(); i++) {
			char c = passwort.charAt(i);
			if (Character.isLowerCase(c)) {
				return true;
			}
		}
		return false;
	}

	static boolean enthaeltZiffern(String passwort) {
		for (int i = 0; i < passwort.length(); i++) {
			char c = passwort.charAt(i);
			if (Character.isDigit(c)) {
				return true;
			}
		}
		return false;
	}

	static boolean enthaeltSonderzeichen(String passwort) {
		for (int i = 0; i < passwort.length(); i++) {
			char c = passwort.charAt(i);
			switch (c) {
				case '.', '#', '&':
					return true;
			}
		}
		return false;
	}

	static boolean istGutesPasswort(String passwort) {
		if (!istLangGenug(passwort)) {
			System.out.println("Passwort ist zu kurz.");
			return false;
		}
		if (!enthaeltGrossbuchstaben(passwort)) {
			System.out.println("Passwort enthält keine Großbuchstaben.");
			return false;
		}
		if (!enthaeltKleinbuchstaben(passwort)) {
			System.out.println("Passwort enthält keine Kleinbuchstaben.");
			return false;
		}
		if (!enthaeltZiffern(passwort)) {
			System.out.println("Passwort enthält keine Ziffern.");
			return false;
		}
		return true;
	}

	static boolean istSehrGutesPasswort(String passwort) {
		if (!istGutesPasswort(passwort)) {
			return false;
		}
		if (!enthaeltSonderzeichen(passwort)) {
			System.out.println("Passwort enthält keine Sonderzeichen.");
			return false;
		}
		return true;
	}

	public static void main(String[] args) {
		String passwort = "Pass8wort&";
		if (istGutesPasswort(passwort)){
			if(istSehrGutesPasswort(passwort)){
				System.out.println("Sehr gutes Passwort.");
			}else{
				System.out.println("Gutes Passwort.");
			}
		}else{
			System.out.println("Kein gutes Passwort.");
		}
	}
}

# Methoden (1)

## 1. Rechtwinkliges Dreieck

**Aufgabenstellung:** Schreiben Sie ein Java-Programm, das prüft, ob ein Dreieck rechtwinklig ist. Dazu können Sie den *Satz des Pythagoras* verwenden:

#### Satz des Pythagoras

In einem rechtwinkligen Dreieck gilt:

$$
a^2 + b^2 = c^2
$$

Dabei sind **a** und **b** die Katheten und **c** die Hypotenuse (die dem rechten Winkel gegenüberliegt und die längste Seite ist).

#### Schritte
1. Schreiben Sie eine Methode, der die 3 Seitenlängen des Dreieckes als Parameter `x`, `y`und `z` übergeben werden (Achtung: Alle drei Parameter könnten die Hypotenuse sein).
2. Geben Sie in Ihrem Hauptprogramm `true` aus, falls ein Dreieck rechtwinklig ist, andernfalls `false`. (Kein Einlesen von der Konsole notwendig)

## 2. Collatz-Folge

**Aufgabenstellung:** Die **Collatz-Folge** (Lothar Collatz, 1937) ist eine Zahlenfolge, die ausgehend von einer positiven ganzen Zahl $n$ nach folgenden Regeln gebildet wird:

- Wenn $n$ **gerade** ist, dann gilt:
  $$
  n_{k+1} = \frac{n_k}{2}
  $$
- Wenn $n$ **ungerade** ist, dann gilt:
  $$
  n_{k+1} = 3n_k + 1
  $$

Diese Schritte werden wiederholt, solange $n > 1$ gilt.  
Die Collatz‑Vermutung behauptet, dass jede Folge auf 4, 2, 1 endet, aber warum das so ist, ist bis heute ungeklärt und ein ungelöstes Problem der Mathematik.

Schreiben Sie ein Java-Programm, das zum Einen die Collatz-Folge für eine Startzahl und zum Anderen den größten erreichten Zwischenwert ausgibt.

*Quelle:* "Captain CiaoCiao erobert Java – Das Trainingsbuch für besseres Java" von Christian Ullenboom.

## 3. Passwortprüfung

**Aufgabenstellung:** Schreiben Sie ein Java‑Programm, das eine Passwortprüfung durchführt.

#### Kriterien
1. Mindestlänge von 8 Zeichen
2. Enthält
	- Großbuchstaben
	- Kleinbuchstaben
	- Ziffern
3. Enthält mind. eines dieser Sonderzeichen: `.`, `#` oder `&`

#### Schritte
1. Schreiben Sie für jede Prüfung eine eigene Methode.
2. Ein Passwort ist gut, wenn es Kriterien 1 + 2 erfüllt. Wenn es zusätzlich noch Kriterium 3 erfüllt, ist es sehr gut. Ansonsten ist es nicht gut.
2. Geben Sie in Ihrem Hauptprogramm aus, ob ein Passwort nicht gut, gut oder sehr gut ist. (Kein Einlesen von der Konsole notwendig)

## 4. Willkommensgruß
**Aufgabenstellung:** Erweitern Sie das Java-Programm `Willkommensgruß` so, dass es zusätzlich zu

```java
static void funkeln()
```

auch noch folgende Methoden gibt, die sich ggf. gegenseitig aufrufen können:

```java
static void funkeln(int len)

static void funkeln(int len, String zeichen)

static void funkeln(String prefix, int len, String zeichen, String suffix)
```

Rufen Sie jede der Methoden mind. einmal in Ihrer `main`-Methode auf.

## 5. Polygone

**Aufgabenstellung:** Erstellen Sie eine Java-Methode, die aus einer variablen Anzahl ganzzahliger Koordinaten ein SVG‑Polygon erzeugt:
```svg
<svg width="BREITE" height="HÖHE">
  <polygon points="x1,y1 x2,y2 x3,y3 ..." />
</svg>
```

#### Schritte
1. Die Methode soll:
	1. bei fehlerhaften Eingabedaten eine entsprechende Meldung ausgeben. Eine Eingabe ist gültig, wenn die Anzahl der übergebenen Koordinaten größer 0 und gerade ist.
	2. die Koordinaten im richtigen Format in ein <polygon>‑Element eifügen.
	3. das vollständige SVG-Element in der Konsole ausgeben.
3. Rufen Sie die Methode mit Beispielwerten in der `main`-Methode auf.
public class RightTriangle {

	static boolean isRightTriangle(double x, double y, double z) {
		//Hypotenuse auf z legen
		if (x > z) {
			double temp = x;
			x = z;
			z = temp;
		}
		if (y > z) {
			double temp = y;
			y = z;
			z = temp;
		}

		double squareX = x * x;
		double squareY = y * y;
		double squareZ = z * z;

		boolean rightAngle = (squareX + squareY == squareZ);
		return rightAngle;
	}

	public static void main(String[] args) {
		System.out.println(isRightTriangle(5, 4, 3));
	}
}

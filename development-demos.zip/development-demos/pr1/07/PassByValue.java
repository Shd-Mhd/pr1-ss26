public class PassByValue {

	/**
	 * Verdoppelt eine Zahl und gibt das Ergebnis aus
	 * 
	 * @param a zu verdoppelnde Zahl
	 */
	static void verdopple(int a) {
		a = a * 2;
		System.out.println("a=" + a);
	}

	static void verdopple(int[] a) {
		System.out.print("a=[");
		for (int j = 0; j < a.length; j++) {
			a[j] = a[j] * 2;
			System.out.print(a[j]);
			System.out.print(",");
		}
		System.out.println("]");
	}

	static void verdopple2(int[] a) {
		System.out.print("a=[");
		for (int i : a) {
			i = i * 2;
			System.out.print(i);
			System.out.print(",");
		}
		System.out.println("]");
	}

	public static void main(String[] args) {
		int b = 4;
		verdopple(b);
		System.out.println("b=" + b);

		int[] c = { 2, 3, 4 };
		verdopple(c);
		System.out.print("c=[");
		for (int i : c) {
			System.out.print(i);
			System.out.print(",");
		}
		System.out.println("]");
	}
}

public class Willkommensgruss {
	static void funkeln() {
		final String STERNE = "\u2728";
		for (int i = 0; i < 10; i++) {
			System.out.print(STERNE);
		}
		System.out.println();
	}
	static void willkommen() {
		final String GRUß = "Herzlich Willkommen!";
		System.out.println(GRUß);
	}

	public static void main(String[] args) {
		funkeln();
		willkommen();
		funkeln();
	}
}

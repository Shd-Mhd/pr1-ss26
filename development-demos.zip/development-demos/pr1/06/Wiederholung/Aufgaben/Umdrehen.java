public class Umdrehen {
	public static void main(String[] args) {
		int[] gewinne = new int[10];
		for (int i = 0; i < gewinne.length; i++) {
			gewinne[i] = 10 + ((int) (Math.random() * 100) * 10); // Gewinne liegen zwischen 10 und 1000 in 10er-Schritten
		}
		System.out.print("Vorher: ");
		for (int i : gewinne) {
			System.out.print(i + " ");
		}

		int letzterIndex = gewinne.length - 1;
		for (int i = 0; i < gewinne.length / 2; i++) {
			int temp = gewinne[i];
			gewinne[i] = gewinne[letzterIndex - i];
			gewinne[letzterIndex - i] = temp;
		}

		System.out.print("\nNachher: ");
		for (int i : gewinne) {
			System.out.print(i + " ");
		}
		System.out.println();
	}
}

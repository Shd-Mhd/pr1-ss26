public class Sudoku {
	public static void main(String[] args) {
		int[][] miniFeld = new int[3][3];
		for (int i = 0; i < miniFeld.length; i++) {
			for (int j = 0; j < miniFeld[i].length; j++) {
				miniFeld[i][j] = 1 + (int) (Math.random() * 9); // Werte der Felder liegen zwischen 1 und 9
			}
		}
		System.out.println("Sudoku-Mini-Feld: ");
		for (int[] reihe : miniFeld) {
			for (int feld : reihe) {
				System.out.print(feld + " ");
			}
			System.out.println();
		}
		boolean gueltig = true;
		for (int gesucht = 1; gesucht <= 9; gesucht++) {
			int reihenIndex = 0;
			boolean gefunden = false;
			do {
				int spaltenIndex = 0;
				do {
					gefunden = miniFeld[reihenIndex][spaltenIndex] == gesucht;
					spaltenIndex++;
				} while (!gefunden && spaltenIndex < miniFeld[reihenIndex].length);
				reihenIndex++;
			} while (!gefunden && reihenIndex < miniFeld.length);
			if (!gefunden) {
				System.out.println("Fehlende Zahl: " + gesucht);
				gueltig = false;
			}
		}
		if (gueltig)
			System.out.println("Gültig");
	}
}

public class Perlenkette {
	public static void main(String[] args) {
		int[] perlenreihen = new int[15];
		for (int i = 0; i < perlenreihen.length; i++) {
			perlenreihen[i] = 1 + (int) (Math.random() * 20); // Anzahl der Perlen in einer Perlenreihe liegen zwischen 1 und 20
		}
		System.out.print("Perlenreihen: ");
		for (int i : perlenreihen) {
			System.out.print(i + " ");
		}

		boolean aufteilungGefunden = false;
		int aktuelleGrenze = 0;
		int zoya = 0;
		int zara = 0;
		do {
			// neue Verteilung berechnen
			zoya = 0;
			zara = 0;
			for (int j = 0; j <= aktuelleGrenze; j++) {
				zoya += perlenreihen[j];
			}
			for (int j = aktuelleGrenze + 1; j < perlenreihen.length; j++) {
				zara += perlenreihen[j];
			}
			// Absolute Differenz bestimmen
			int differenz = zoya - zara;
			int absDifferenz = differenz > 0 ? differenz : -differenz;
			// Maximum bestimmen
			int max = zoya > zara ? zoya : zara;
			// Prozentualen Unterschied bestimmen
			double prozent = ((double) absDifferenz / max) * 100.0;
			if (prozent <= 5.0) {
				aufteilungGefunden = true;
			}
			aktuelleGrenze++;
		} while (aktuelleGrenze < perlenreihen.length && !aufteilungGefunden);
		if (aufteilungGefunden) {
			System.out.println("\nGrenze gefunden: " + aktuelleGrenze + " -> Zoya: " + zoya + " Zara: " + zara);
		} else {
			System.out.println("\nLeider kann nicht gerecht aufgeteilt werden.");
		}
	}
}

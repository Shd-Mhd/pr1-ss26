# Arrays

## 1. Umdrehen

**Aufgabenstellung:** Schreiben Sie ein Java-Programm, das ein Array umdreht.

#### Schritte
1. Erzeugen Sie 10 zufällige Zahlen zwischen 10 und 1000, die durch 10 teilbar sind.
2. Speichern Sie diese in einem Array und geben dieses in der Konsole aus.
3. Drehen Sie das Array um, ohne ein neues Array zu erzeugen (s. oben).
4. Geben Sie auch dieses Array aus.

*Hinweis:* Ein Array *umzudrehen* bedeutet, dass das erste Element mit dem letzten Element vertauscht wird, das zweite mit dem zweitletzten usw.

## 2. Perlen

**Aufgabenstellung:** Sie haben 15 unterschiedliche Perlenreihen, die jeweils 1-20 Perlen einer Farbe enthalten. Die Perlenmuster sind zu einer langen, bunten Kette zusammengefügt. Nun müssen sie diese Kette zwischen Ihren Nichten Zara und Zoya aufteilen, so dass beide in etwa gleich viele Perlen erhalten. Dabei dürfen die Perlenreihen einer Farbe nicht zerschnitten werden, d.h. ein Schnitt darf nur zwischen zwei Perlenreihen erfolgen. Schreiben Sie ein Java-Programm. das Sie dabei unterstützt, die richtige Schnittposition in der Kette zu finden.

#### Schritte
1. Belegen Sie die 15 Perlenreihen mit zufälligen Zahlen zwischen 1 und 20 (Anzahl der gleichfarbigen Perlen).
2. Eine faire Aufteilung bedeutet hier, dass weder Zoya noch Zara mehr als 5% der Perlen der anderen erhält.
3. Finden Sie durch iteratives Vorgehen eine geeignete Schnittposition, um die Kette aufzuteilen.
4. Geben Sie die Perlenreihe an, nach der der Schnitt erfolgt, sowie die Anzahl der Perlen, die Zoya und Zara jeweils erhalten.
4. Falls keine faire Aufteilung möglich ist, geben Sie eine Meldung aus.

## 3. Mini-Sudoku

**Aufgabenstellung:** Schreiben Sie ein Java-Programm, das ein kleines 3x3-Feld zufällig mit ganzen Zahlen zwischen 1-9 belegt und dann prüft, ob es ein gültiges Mini-Sudoku-Feld ist. Ein gültiges Mini-Sudoku-Feld enthält alle Zahlen zwischen 1 und 9 genau einmal.

#### Schritte
1. Belegen Sie ein 3x3-Feld mit zufälligen Zahlen und geben Sie es geeignet in der Konsole aus.
2. Geben Sie alle fehlenden Zahlen aus, falls das Mini-Sudoku-Feld ungültig ist.
3. Geben Sie eine Meldung aus, falls das Feld gültig ist.
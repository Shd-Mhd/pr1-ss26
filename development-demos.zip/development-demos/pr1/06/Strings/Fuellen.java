import java.util.Scanner;

public class Fuellen {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String satz = scanner.nextLine();
		String fuellZeichen = scanner.next(); //bis zum Leerzeichen

		String neuerSatz = new String();
		for (int i = 0; i < satz.length(); i++) {
			neuerSatz += satz.charAt(i) + fuellZeichen;
		}
		System.out.println(neuerSatz);
		scanner.close();
	}
}

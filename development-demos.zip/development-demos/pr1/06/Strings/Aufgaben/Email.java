import java.util.Scanner;

public class Email {
	public static void main(String[] args) {
		final char KLAMMERAEFFCHEN = '@';
		Scanner scanner = new Scanner(System.in);
		System.out.print("E-Mail: ");
		String email = scanner.next(); // liest solange ein, bis mind. ein Zeichen

		int pos = -1;
		int anz = 0;
		for (int i = 0; i < email.length(); i++) { // Prüfen, wie oft und wo @-Zeichen vorkommt
			char pruefZeichen = email.charAt(i);
			if (pruefZeichen == KLAMMERAEFFCHEN) {
				anz++;
				pos = i;
			}
		}

		if (anz == 1 && pos > 0 && pos != email.length() - 1) { // Prüfen, ob @-Zeichen mehrmals oder am Anfang oder am
																// Ende vorkommt
			String benutzer = email.substring(0, pos);
			String domain = email.substring(pos + 1);

			System.out.println("Benutzername: " + benutzer);
			System.out.println("Domain: " + domain);
		} else {
			System.out.println("Ungültig");
		}

		scanner.close();
	}
}

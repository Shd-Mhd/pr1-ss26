# Strings

## 1. Verdopplung

**Aufgabenstellung:** Schreiben Sie ein Java-Programm, das prüft, ob in einem String alle Zeichen zweimal hintereinander vorkommen.

#### Schritte
1. Lesen Sie einen `String` (mit Leerzeichen) von der Konsole ein.
2. Falls der `String` keine oder eine ungerade Anzahl von Zeichen enthält, wird "Nicht korrekt: Keine oder ungerade Anzahl Zeichen." in der Konsole ausgegeben.
3. Falls jedes Zeichen zweimal hintereinander vorkommt, wird "Korrekt" ausgegeben.
4. Falls ein Zeichen nicht doppelt hintereinander vorkommt, wird "Nicht korrekt: " gefolgt von der Position des ersten falschen Zeichens ausgegeben.

*Quelle:* "Captain CiaoCiao erobert Java – Das Trainingsbuch für besseres Java" von Christian Ullenboom.

## 2. Befragung

**Aufgabenstellung:** Schreiben Sie ein Java-Programm, das auf alle Fragen trotzige Antworten gibt.

#### Schritte
1. Lesen Sie eine Eingabe von der Kommandozeile ein.
2. Es gibt 3 unterschiedliche Antwortmöglichkeiten:
	1. Endet die Eingabe mit einem `?`, dann wird die Eingabe gefolgt von "Keine Ahnung!" ausgegeben.
	2. Endet die Eingabe nicht mit `?`, dann wird nichts ausgegeben.
	3. Ist die Eingabe "Keine Ahnung?" (unabhängig von Groß- und Kleinschreibung), dann wird "Genau!" ausgegeben.
3. Verwenden Sie geeignete Konstanten.

*Hinweis 1:* Die Methode `equalsIgnoreCase(...)` beachtet beim Vergleich die Groß- und Kleinschreibung NICHT. Der Test findet Zeichen für Zeichen statt, d.h. auch unterschiedliche Groß- und Kleinschreibung innerhalb der Strings wird ignoriert.

*Hinweis 2:* Die Methode `substring(int, int)` erhält den Anfang und das Ende einer gewünschten Teilzeichenkette als Parameter. Während die Startposition inklusiv ist, ist die Endposition exklusiv.

*Quelle:* "Captain CiaoCiao erobert Java – Das Trainingsbuch für besseres Java" von Christian Ullenboom.

## 3. Email

**Aufgabenstellung:** Schreiben Sie ein Java‑Programm, das eine Eingabe daraufhin prüft, ob ein @-Zeichen genau einmal enthalten ist und weder am Anfang noch am Ende steht. Anschließend soll der Teil vor dem @-Zeichen (Benutzernamen) und danach (Domain) ausgegeben werden.

#### Schritte
1. Lesen Sie einen `String` (ohne Leerzeichen) von der Konsole ein.
2. Prüfen Sie ob, das @-Zeichen genau einmal vorkommt und weder am Anfang noch am Ende steht. Falls diese Prüfung fehlschlägt, geben Sie "Ungültig" aus.
3. Falls die Prüfung nicht fehlschlägt, geben Sie den Teil vor dem @-Zeichen als "Benutzername" und den Teil danach als "Domain" aus.

*Hinweis:* Die Methode `substring(int, int)` erhält den Anfang und das Ende einer gewünschten Teilzeichenkette als Parameter. Während die Startposition inklusiv ist, ist die Endposition exklusiv.
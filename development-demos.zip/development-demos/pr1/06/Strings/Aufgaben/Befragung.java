import java.util.Scanner;

public class Befragung {
	public static void main(String[] args) {
		final String TROTZIGE_ANTWORT = "Keine Ahnung";
		final String VERAEPPELUNG = "Genau!";
		final char FRAGEZEICHEN = '?';
		final char AUSRUFEZEICHEN = '!';

		Scanner scanner = new Scanner(System.in);
		String frage = scanner.nextLine();

		if (frage.length() > 0) {
			char letztesZeichen = frage.charAt(frage.length() - 1);
			if (letztesZeichen == FRAGEZEICHEN) {
				String testString = frage.substring(0, frage.length() - 1);
				if (testString.equalsIgnoreCase(TROTZIGE_ANTWORT)) {
					System.out.println(VERAEPPELUNG);
				} else {
					System.out.println(frage + " " + TROTZIGE_ANTWORT + AUSRUFEZEICHEN);
				}
			}
		}

		scanner.close();
	}
}

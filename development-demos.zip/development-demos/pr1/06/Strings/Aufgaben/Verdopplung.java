import java.util.Scanner;

public class Verdopplung {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String nachricht = scanner.nextLine();
		if (nachricht.length() != 0 && nachricht.length() % 2 == 0) {
			boolean fehler = false;
			int i = 0;
			do {
				char pruefZeichen = nachricht.charAt(i);
				char folgeZeichen = nachricht.charAt(i + 1);
				if (pruefZeichen != folgeZeichen) {
					fehler = true;
					System.out.println("Nicht korrekt: " + (i + 1));
				}
				i = i + 2;
			} while (!fehler && i < nachricht.length()); // Achtung: warum ist das hier in Ordnung?
			if (!fehler) {
				System.out.println("Korrekt");
			}

		} else {
			System.out.println("Nicht korrekt: Keine oder ungerade Anzahl Zeichen.");
		}

		scanner.close();
	}
}

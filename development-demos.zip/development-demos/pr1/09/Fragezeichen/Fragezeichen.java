package Fragezeichen;

import java.util.Scanner;

public class Fragezeichen {
	String vorname;
	String nachname;
	String geburtstag;

	void zumGeburtstagGratulieren(Scanner scanner) {
		System.out.print("Ist heute der " + geburtstag + "? ");
		boolean hatGeburtstag = scanner.nextBoolean();
		if (hatGeburtstag) {
			System.out.println(
					"Happy Birthday, " + vorname + " " + nachname + "!");
		}
	}
}

package Fragezeichen;

import java.util.Scanner;

public class GeschenkeFragezeichen {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Fragezeichen[] detektive = new Fragezeichen[3];

		detektive[0] = new Fragezeichen();
		detektive[0].vorname = "Justus";
		detektive[0].nachname = "Jonas";
		detektive[0].geburtstag = "1.4.1950";

		detektive[1] = new Fragezeichen();
		detektive[1].vorname = "Bob";
		detektive[1].nachname = "Andrews";
		detektive[1].geburtstag = "11.9.1950";

		detektive[2] = new Fragezeichen();
		detektive[2].vorname = "Peter";
		detektive[2].nachname = "Shaw";
		detektive[2].geburtstag = "17.6.1950";

		for (Fragezeichen aktuellerDetektiv : detektive) {
			aktuellerDetektiv.zumGeburtstagGratulieren(scanner);
		}
		scanner.close();
	}
}

package Bankkonto;

public class Application {
	public static void main(String[] args) {
		Bankkonto konto = new Bankkonto();
		konto.iban = "DE12 3456 7890 1234 5678 90";
		konto.istAktiv = true;
		konto.dispoLimit = 500.0;
		konto.kontostand = 1200.0;
		konto.geldAbheben(200);
		konto.kontostandAusgeben();
	}
}

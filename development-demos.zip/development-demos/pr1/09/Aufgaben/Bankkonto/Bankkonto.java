package Bankkonto;

public class Bankkonto {
	String iban;
	double kontostand;
	double dispoLimit;
	boolean istAktiv;

	void geldAbheben(double wert) {
		if (istAktiv) {
			double neuKontostand = kontostand - wert;
			if (neuKontostand < -dispoLimit) {
				double neuWert = dispoLimit + kontostand;
				kontostand = kontostand - neuWert;
				System.out.println(
						iban + ": Dispolimit wurde erreicht. Es konnten nur " + neuWert + "€ abgehoben werden.");
			} else {
				kontostand = neuKontostand;
				System.out.println(iban + ": " + wert + "€ wurden abgehoben.");
			}
		} else {
			System.out.println(iban + ": Konto nicht aktiv. Es wurde nichts abgehoben.");
		}
	}

	void kontostandAusgeben(){
		System.out.println(iban + ": Aktueller Kontostand ist " + kontostand + "€.");
	}
}

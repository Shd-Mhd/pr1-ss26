package Rechteck;
public class Rechteck {
    int breite;
    int hoehe;

	int flaecheBerechnen(){
		return breite * hoehe;
	}
}
package Rechteck;

public class Application {
	public static void main(String[] args) {
		Rechteck rect = new Rechteck();
		rect.breite = 200;
		rect.hoehe = 55;
		System.out.println("Fläche: " +rect.flaecheBerechnen());
	}
}

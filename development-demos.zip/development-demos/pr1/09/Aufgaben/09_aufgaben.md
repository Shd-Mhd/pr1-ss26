# Klassen-Methoden

## 1. UML-Diagramme
**Aufgabenstellung:** Zeichnen Sie UML-Diagramme zu folgenden Klassen mit `draw.io`:

![Klassen](09_aufgaben.png)

#### Schritte
1. Erstellen Sie zunächst die Klassen mit den angegebenen Attributen.
2. Erweitern Sie Ihre UML-Klassen mit jeweils einer geeigneten Methode.

## 2. Rechteck

**Aufgabenstellung:** Erstellen Sie eine Java-Klasse zum UML-Diagramm [Rechteck](Rechteck/Rechteck.drawio) und schreiben Sie ein Programm, welches ein Objekt der Klasse erstellt, die Attribute mit sinnvollen Werten belegt und die Methode testweise ausführt.

## 3. Punkt

**Aufgabenstellung:** Erstellen Sie eine Java-Klasse zum UML-Diagramm [Punkt](Punkt/Punkt.drawio) und schreiben Sie ein Programm, welches ein Objekt der Klasse erstellt, die Attribute mit sinnvollen Werten belegt und die Methode testweise ausführt. Die Methode `malePunkt()` zeichnet dabei einen Kreis mit einer bestimmten Farbe und einem bestimmten Radius um den Punkt im SVG-Format:

#### Beispiel
```svg
<svg height='400' width='400'>
 <circle cx='200' cy='200' r='100' fill='green' />
</svg>
```

## 4. Auto

**Aufgabenstellung:** Erstellen Sie eine Java-Klasse zum UML-Diagramm [Auto](Auto/Auto.drawio) und schreiben Sie ein Programm, welches ein Objekt der Klasse erstellt, die Attribute mit sinnvollen Werten belegt und die Methode testweise ausführt. 

#### Hinweis
Ein Elektro-Auto ist foerderfaehig, wenn die Erstzulassung ab dem 01.01.2026 liegt.

## 5. Bankkonto

**Aufgabenstellung:** Erstellen Sie eine Java-Klasse zum UML-Diagramm [Bankkonto](Bankkonto/Bankkonto.drawio) und schreiben Sie ein Programm, welches ein Objekt der Klasse erstellt, die Attribute mit sinnvollen Werten belegt und die Methode testweise ausführt.

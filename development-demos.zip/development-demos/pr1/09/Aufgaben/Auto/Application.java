package Auto;

public class Application {
	public static void main(String[] args) {
		Auto id3 = new Auto();
		id3.erstzulassung = 2025;
		id3.gewicht = 1725.0;
		id3.faehrtElektrisch = true;
		System.out.println(id3.erstelleBeschreibung());
		System.out.println("Das Auto ist förderfähig für das Jahr 2026: " + id3.foerderfaehig());
	}
}

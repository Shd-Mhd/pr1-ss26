package Auto;

public class Auto {
	short erstzulassung;
	double gewicht;
	boolean faehrtElektrisch;

	String erstelleBeschreibung() {
		return "Erstzulassung: " + erstzulassung + ", Gewicht: " + gewicht + " kg, elektrisch: "
				+ (faehrtElektrisch ? "ja" : "nein");
	}

	boolean foerderfaehig() {
		final short FOERDERJAHR = 2026;
		return this.faehrtElektrisch && (this.erstzulassung >= FOERDERJAHR);
	}
}
package Punkt;

public class Punkt {
	int x;
	int y;

	String malePunkt(short radius, String colour) {
		return "<svg height='400' width='400'>\n <circle cx='" + x + "' cy='" + y + "' r='" + radius + "' fill='"
				+ colour + "' />\n</svg>";
	}
}
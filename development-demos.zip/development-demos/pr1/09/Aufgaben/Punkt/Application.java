package Punkt;

public class Application {
	public static void main(String[] args) {
		Punkt p1 = new Punkt();
		p1.x = 300;
		p1.y = 250;
		System.out.println(p1.malePunkt((short) 10, "green"));
	}
}

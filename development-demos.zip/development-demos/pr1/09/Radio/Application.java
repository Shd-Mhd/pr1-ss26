package Radio;

public class Application {
	public static void main(String[] args) {
		Radio omasRadio = new Radio();
		omasRadio.isOn = true;
		omasRadio.lautstaerke = 12;
		int idOma = System.identityHashCode(omasRadio);

		Radio opasRadio = new Radio();
		opasRadio.isOn = true;
		opasRadio.lautstaerke = 15;
		int idOpa = System.identityHashCode(opasRadio);
		Radio grossvatersRadio = opasRadio;
		int idGrossvater = System.identityHashCode(grossvatersRadio);

		System.out.println(idOma);
		System.out.println(idOpa);
		System.out.println(idGrossvater);

		System.out.println(idOma == idOpa);
		System.out.println(idOpa == idGrossvater);

		System.out.println("--- Omas Radio ---");
		System.out.println("Initiale Lautstärke: " + omasRadio.lautstaerke);
		omasRadio.lautstaerkeErhoehen();
		omasRadio.lautstaerkeErhoehen();
		System.out.println(omasRadio.ausgabeString());

		omasRadio.lautstaerkeVerringern();
		System.out.println(omasRadio.ausgabeString());

		omasRadio.ausschalten();
		System.out.println(omasRadio.ausgabeString());

		System.out.println("--- Opas Radio ---");
		System.out.println("Initiale Lautstärke: " + opasRadio.lautstaerke);
		omasRadio.lautstaerkeErhoehen();
		omasRadio.lautstaerkeErhoehen();
		System.out.println(opasRadio.ausgabeString());
		System.out.println(grossvatersRadio.ausgabeString());

		Steckdose steckdose = new Steckdose();
		steckdose.radio = opasRadio;
		steckdose.stromausfall();
		System.out.println("--- Opas Radio nach Stromausfall---");
		System.out.println(opasRadio.ausgabeString());
	}
}

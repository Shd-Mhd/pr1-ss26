package Radio;

public class Radio {
	boolean isOn;
	int lautstaerke;

	void lautstaerkeAendern(int wert) {
		int neueLautstaerke = lautstaerke + wert;
		if (neueLautstaerke < 0) {
			neueLautstaerke = 0;
		} else if (neueLautstaerke > 100) {
			neueLautstaerke = 100;
		}
		lautstaerke = neueLautstaerke;
	}

	void lautstaerkeErhoehen() {
		lautstaerkeAendern(1);
	}

	void lautstaerkeVerringern() {
		lautstaerkeAendern(-1);
	}

	void anschalten(){
		isOn = true;
	}

	void ausschalten(){
		isOn = false;
	}

	public String ausgabeString(){
		return "Radio[laustärke=" + lautstaerke + ", " + (isOn ? "an" : "aus") + "]";
	}
}

package Radio;

public class Steckdose {
	Radio radio;
	void stromausfall(){
		radio.isOn = false;
		radio.lautstaerke = 0;
	}
}
